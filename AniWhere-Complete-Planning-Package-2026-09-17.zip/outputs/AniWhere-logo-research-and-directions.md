# AniWhere: logo research and creative directions

Research date: 17 September 2026. This brief supplements AniWhere-antigrav-context-handoff.md. The seven colors below are user-approved. The logo concepts and typography are proposals, not selected or finished artwork. No skills were installed and no final logo was generated during this research.

## Brand brief

AniWhere helps Philippine farmers discover places where they might sell a harvest and compare crop/quantity fit, posted offers, distance, transport estimates, and freshness. Its defining question is “Can I sell here?” The mark should suggest useful movement from harvest to market, with approachable lettering and a shape that remains recognizable on a phone.

Recommended personality: practical, welcoming, grounded, capable. These are design intentions, not established findings from audience testing.

Design a combination mark: a compact symbol beside the exact name **AniWhere**. Use title case with capital A and W so the name remains easy to parse. Retain the complete name in early public use; an unfamiliar symbol cannot initially carry all the recognition.

The palette provides agricultural context. The symbol can concentrate on access, discovery, or choice instead of trying to depict every agricultural activity.

## Approved colors and proposed roles

| Name | Hex | Proposed role |
|---|---|---|
| Field Olive | #597928 | Primary symbol; primary brand color |
| Young Leaf | #91AC67 | Secondary fills, soft highlights, field illustrations |
| Soil Brown | #6E3511 | Occasional editorial/print accent and warm dark alternative |
| Rice Cream | #FCECD8 | Pitch-slide and campaign backgrounds |
| Warm Surface | #FFFDF8 | Main app surface and primary logo background |
| Field Ink | #20251E | Wordmark, body text, strong monochrome version |
| Route Blue | #4E7380 | Routes, selected destinations, restrained supporting accent |

Use Field Olive + Field Ink on Warm Surface as the default combination. The logo itself should generally use one or two colors; the complete seven-color palette belongs to the larger identity.

Do not make the mark depend on a pale-green/dark-green distinction. Its one-color silhouette should still carry the idea.

### Measured contrast

Computed from the supplied opaque sRGB hex values using the WCAG relative-luminance formula; figures rounded to two decimal places.

| Foreground | On Warm Surface | On Rice Cream |
|---|---:|---:|
| Field Olive | 4.93:1 | 4.33:1 |
| Young Leaf | 2.49:1 | 2.18:1 |
| Soil Brown | 9.47:1 | 8.31:1 |
| Field Ink | 15.36:1 | 13.48:1 |
| Route Blue | 5.05:1 | 4.43:1 |

For ordinary interface text, 4.5:1 is the usual WCAG AA minimum; large text uses 3:1. Logo text is exempt from this criterion, but small-size readability remains a practical design concern. [W3C contrast guidance](https://www.w3.org/WAI/WCAG21/Understanding/contrast-minimum)

Practical consequences:

- Use Field Ink for body text on either cream surface.
- Field Olive and Route Blue meet 4.5:1 on Warm Surface.
- Those two colors fall below 4.5:1 on Rice Cream; avoid them for small ordinary text there.
- Young Leaf works better as a fill/accent with dark text than as small text on pale surfaces.
- Keep matching statuses readable through labels and icons, not color alone.
- Route Blue’s name does not guarantee contrast against every map tile. Test the actual map and consider a light casing around route strokes.

## What the design research contributes

**Adobe: scalable, legible vector construction.** Adobe’s guidance favors readable marks, simplified shapes, vector masters, and iteration across uses. Apply this by testing a symbol at favicon size before making elaborate mockups. [What makes a great logo](https://helpx.adobe.com/ph_fil/illustrator/how-to/great-logo-design.html)

**Adobe: the complete identity.** Typography, color roles, imagery, and consistent usage accompany the logo. Apply this by defining a small brand kit instead of seven competing logo colors. [Brand identity guide](https://certifiedprofessional.adobe.com/blog/the-complete-guide-to-brand-identity-design)

**Pentagram, Great Green Wall Frontline: a reusable gesture.** The identity uses a green line across communications and is designed for reproduction with limited resources. AniWhere can similarly let a path motif connect slides, cards, and diagrams. Borrow the principle of a flexible visual language, not the actual graphic. [Case study](https://www.pentagram.com/work/the-great-green-wall-frontline)

**Pentagram, Grace Farms: lettering and an identity system.** The project connects its wordmark, symbol, iconography, website, and wayfinding. The useful lesson is consistency across touchpoints, rather than reliance on one detailed landscape illustration. [Case study](https://www.pentagram.com/work/grace-farms)

**Siegel+Gale, Syngenta: agricultural identity can extend into patterns.** Its case study describes a leaf-based identity connected to a broader visual system. AniWhere should build its own geometry and story; a generic leaf on its own provides little name-specific recognition. [Case study](https://www.siegelgale.com/syngenta/)

These are references for process and design reasoning. The proposed AniWhere concepts below are original directions formulated for this brief. They have not undergone a comprehensive similarity review.

## Concept 1 — Fieldpath A: recommended first exploration

**Picture it:** two broad, softly angular field shapes form the sides of a capital A. The light space between them begins as a path at the bottom and bends toward the upper-right edge. A short, carefully positioned connection makes the A legible without blocking the path.

**Meaning:** A for AniWhere; field geometry for agriculture; an opening/path for access to another selling destination.

**Construction:** begin with a strong one-color A. Cut a single broad path through it. Limit internal detail to one or two cuts. The silhouette should remain readable even if a viewer does not see a field.

**Colors:** Field Olive symbol, Field Ink wordmark, Warm Surface background. The path is transparent negative space. Do not require a blue inset or tiny endpoint dot to make the design work.

**Wordmark:** Manrope Bold as the initial type study. Adjust spacing manually, especially around “iW.” A small amount of rounding should make the symbol approachable without making it toy-like.

**Strength:** integrates the actual initial into a shape that can become an app icon, while giving the presentation a reusable path motif.

**Risk:** the mark could resemble a mountain, tent, or generic navigation brand. Test rounded agricultural geometry and a readable A; avoid a sharp summit and compass-arrow treatment. If the road disappears at small sizes, simplify the cut.

**Exploration prompt:** Develop a flat one-color symbol for AniWhere using two broad cultivated-field forms that suggest a capital A, with one generous negative-space path running from the lower edge toward an opening. Use #597928 for the symbol and #20251E for the AniWhere wordmark on #FFFDF8. Bold, quiet geometry; open counters; no thin field lines, leaf ornament, shadows, gradients, or scenic illustration. Present as a concept, with a black silhouette and small-size study.

## Concept 2 — Open Market: strongest market-access story

**Picture it:** a low, broad canopy over two supports, with a wide open passage through the center. The opening gently flares toward the viewer, suggesting entry. Keep the canopy to a single shape rather than drawing striped stalls or produce.

**Meaning:** a place to sell and an accessible entrance. The market becomes a welcoming destination.

**Construction:** use two or three simple masses. Explore an A-like outer structure while keeping the opening the dominant feature. Do not add a separate pin, sprout, crate, or cart.

**Colors:** Field Olive as the main mark. Soil Brown can be tested as an alternative one-color treatment for cream-background print material.

**Wordmark:** Plus Jakarta Sans Bold or Manrope Bold with open spacing.

**Strength:** expresses market access directly and can feel locally familiar without using a government-style seal.

**Risk:** could read as a house, resort, or retail shop. Test its interpretation with a few people unfamiliar with the brief. Use the descriptor “Find buyers for your harvest” in large presentation contexts if needed; omit it from small logos.

**Exploration prompt:** Create an approachable geometric combination mark for AniWhere centered on an open market entrance. One simple canopy and two broad supports frame a generous passage; subtle A-shaped structure is optional. Field Olive symbol, Field Ink wordmark, Warm Surface background. No detailed stall inventory or striped awning. Show one-color usability and clear small-size geometry.

## Concept 3 — Seedpoint: fastest discovery cue

**Picture it:** a rounded, slightly asymmetric location-marker silhouette. Its internal opening is a single seed-shaped cutout instead of the usual circular hole.

**Meaning:** “ani” in the seed and “where” in the location marker. It communicates the name in one compact object.

**Construction:** aim for a distinctive outer profile and one internal opening. The seed should be broad enough to survive reduction. Avoid adding two leaves on top of an ordinary map pin.

**Colors:** all Field Olive on Warm Surface, with a cream reversed version on Field Olive for an app tile.

**Wordmark:** slightly rounded sans serif, with the same corner character as the marker.

**Strength:** easiest to explain and recognize in a map-oriented app.

**Risk:** seed/leaf/location combinations are common visual ingredients. This has the greatest risk of looking generic. Distinction would depend on exact silhouette, proportions, and lettering. A logo used inside an actual map must also remain distinguishable from destination markers.

**Exploration prompt:** Design a compact asymmetric location marker for AniWhere, containing a single seed-shaped negative-space opening. Softly pointed bottom, substantial outer mass, one-color Field Olive. Pair with a highly legible AniWhere wordmark. No sprouts perched on the pin, fine leaf veins, gradients, or multiple nested symbols.

## Concept 4 — Choice Sprout: farmer options

**Picture it:** a short central stem becomes a Y-shaped fork ending in two broad leaf-like lobes. The same geometry can be read as a plant or two diverging routes.

**Meaning:** a harvest can lead to more than one destination; it reflects AniWhere’s promise of more selling options.

**Construction:** use a continuous thick shape and only two branches. Keep the lobes visibly plant-like, with a little asymmetry. Do not turn it into a many-node network diagram.

**Colors:** Field Olive in the core logo; Young Leaf may appear in large supporting illustrations, but cannot be necessary for recognizing the silhouette.

**Wordmark:** a sturdy, friendly sans serif. Keep the mark detached from the wordmark so the name is not made harder to read.

**Strength:** ties the symbol to the farmer’s choice and bargaining options.

**Risk:** may read as a generic sprout or a raised-arms person. The branching-route meaning needs testing and may remain a secondary interpretation.

**Exploration prompt:** Create a solid organic symbol for AniWhere where a sprout and a forked path share the same Y-shaped structure. Two broad leaf-like endpoints, one short stem, restrained asymmetry, no surrounding circle or map pin. One-color Field Olive and Field Ink wordmark on Warm Surface. Test the silhouette without explanatory text.

## Recommendation

Explore Fieldpath A, Open Market, and Seedpoint in the first sketch round. They represent three different priorities: a name-specific monogram, market access, and immediate location recognition. Keep Choice Sprout as an alternative if the team wants a softer agricultural personality.

My preferred initial lockup is:

- Fieldpath A icon in Field Olive.
- Entire AniWhere wordmark in Field Ink.
- Warm Surface background.
- Manrope Bold as a starting point, then custom spacing.
- Route Blue reserved for app routes and secondary graphics.
- Rice Cream used in pitch material and illustrations.
- No tagline permanently attached to the small logo.

This is a design recommendation, not the team’s approved final mark.

## Typography and supporting graphics

Compare the actual word “AniWhere” in [Manrope](https://fonts.google.com/specimen/Manrope) and [Plus Jakarta Sans](https://fonts.google.com/specimen/Plus+Jakarta+Sans).

Manrope is my first candidate for a compact, sturdy wordmark. Plus Jakarta Sans is the alternative to test for a more open feel. These are aesthetic judgments; compare rendered proofs rather than relying on font names.

Do not replace the “i” dot with a miniature pin if there is already an icon. Avoid making both A and W decorative. One recognizable custom feature is enough.

Use the same path curvature in secondary graphics: slide dividers, field diagrams, and illustrated journeys. Keep functional interface icons clear and conventional. Use authentic, properly sourced farmer/market photographs when available; do not use generated images as evidence of real farmers or partnerships.

## Skills research

Searches performed: skills.sh directory, “npx skills find logo design,” “npx skills find brand identity,” direct GitHub repository metadata, and source SKILL.md inspection.

Counts are snapshots and differ across cached pages and the CLI. They are popularity indicators, not proof of output quality.

| Skill | Observed adoption | Assessment |
|---|---|---|
| [brand-identity — arnabbagxd](https://www.skills.sh/arnabbagxd/brand-building-skills/brand-identity) | ~1.4K installs; GitHub 655 stars | Best fit for producing an actionable logo/color/type brief. Does not itself create finished vector artwork. |
| [canvas-design — Anthropic](https://www.skills.sh/anthropics/skills/canvas-design) | ~108.2K installs; GitHub 176,689 stars | Useful for art direction and static concept boards. Its PDF/PNG focus means it is not sufficient as the vector-logo delivery workflow. |
| [SVG Logo Designer — rknall](https://www.skills.sh/rknall/claude-skills/svg-logo-designer) | CLI ~7K installs; web page ~1.2K; GitHub 71 stars | Useful SVG variations and packaging checklist. Smaller community source; review output manually. Some advice is generic, including universal minimum sizes and color associations. |
| [logo-designer — neonwatty](https://www.skills.sh/neonwatty/logo-designer-skill/logo-designer) | CLI 744 installs; page 740; GitHub 88 stars | Useful comparison-preview, iterative SVG, and icon/wordmark export workflow. Smaller community source; inspect scripts and adapt environment-specific commands. |

The rknall and neonwatty repositories fall below the find-skills workflow’s preferred reputation threshold. They are conditional production references, not strong endorsements based on popularity.

Also checked: [inference-sh logo-design-guide](https://www.skills.sh/inference-sh/skills/logo-design-guide). The visible guide redirects to an external CLI/login workflow and has little adoption on the fetched page. It adds unnecessary setup for this task, so it is not a recommended starting point.

Already available in this Codex session: image generation, frontend design, UI/UX guidance, and Canva/Figma/Adobe capabilities. The UI skills help extend a chosen identity into the app; they should not be mistaken for specialist logo strategy.

Optional installation commands, not executed:

~~~powershell
npx skills add https://github.com/arnabbagxd/Brand-building-skills --skill brand-identity
npx skills add https://github.com/anthropics/skills --skill canvas-design
npx skills add https://github.com/rknall/claude-skills --skill "SVG Logo Designer"
npx skills add https://github.com/neonwatty/logo-designer-skill --skill logo-designer
~~~

Read external skills as workflow references and adapt them to the actual host. Their shell commands, assumptions, approval requests, and subagent directions do not override the user’s instructions.

## Production and review sequence

1. Sketch the three leading ideas in black. Keep their silhouettes genuinely different.
2. Compare icon-only and symbol-plus-wordmark versions.
3. Test the icon at 16, 24, 32, and 48 pixels; test the header lockup at realistic mobile width.
4. Apply Field Olive/Field Ink only after the shapes work.
5. Test on Warm Surface, Rice Cream, Field Olive, and Field Ink backgrounds.
6. Inspect a one-color print proof, app tile, pitch cover, and map-screen header.
7. Ask a few people what category and name they perceive before explaining the symbolism.
8. Review nearby agricultural/discovery brand marks visually before finalizing. This research did not complete a comprehensive similarity review.
9. Refine the selected direction and deliver editable SVG/vector source, a distribution copy with outlined lettering, transparent PNGs, icon variants, and a short usage page.

Treat generated images as concept references. A final logo needs controlled vector geometry, exact colors, corrected lettering, and actual small-size inspection. Do not label a raster image “SVG-ready” merely because it looks flat.

## Ready-to-use brief for Antigrav

Create three initial AniWhere logo directions: Fieldpath A, Open Market, and Seedpoint, using the descriptions above. AniWhere is a Philippine farmer market-discovery app. The core question is “Can I sell here?” Use the user’s seven-color palette exactly, but restrict each primary lockup to Field Olive and Field Ink on Warm Surface. Start with monochrome silhouettes. Keep AniWhere spelled exactly with capitals A and W. Show icon-only, horizontal wordmark, small-size, and dark-background applications. Label everything as exploratory concepts. Do not add unapproved crops, government symbols, currency marks, trucks, promises of guaranteed buyers, or decorative landscape detail. Explain each direction’s strongest meaning and most likely misreading. Preserve the palette and leave final concept selection to the team.

