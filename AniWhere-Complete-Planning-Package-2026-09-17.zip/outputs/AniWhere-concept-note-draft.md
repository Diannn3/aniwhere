# AniWhere concept note draft

Drafted for the supplied NextGen Agri Hackathon 2026 template. Proposed functionality is future work. Team identity, institution, academic level and member names still need to be entered. No affiliations, interviews, partnerships or impact results are implied.

## Team and Institutional Details

- Team Name: [Enter team name]
- Institution: [Enter institution]
- Academic Level: [Enter academic level]
- Team Members: [Enter the three members]
- Mentor: [Optional]

## Project Title

AniWhere — Harvest Market Discovery and Adaptive Selling Plans

## Focus Sector

- Digital Agriculture
- Value Chain Development
- Agri-Enterprise Development, if the cooperative planning component is retained

## Problem Statement

Smallholder vegetable farmers must decide where to sell a perishable harvest using incomplete information about buyers, accepted quantities, quality requirements, transport costs and payment schedules. A higher advertised price may yield less money after delivery expenses, while a nearby buyer may accept only part of the harvest. Larger buyers may require volumes that one farmer cannot supply. When an offer changes or a buyer cancels, farmers must find another outlet before the produce loses value.

Existing marketplaces and market-information services already support agricultural discovery, trade and price visibility. The specific gap AniWhere will test is whether farmers and cooperative coordinators benefit from a simple, explainable plan that allocates a harvest across feasible buyers, compares proceeds after selling costs and revises the remaining allocation when demand changes.

The initial prototype will focus on one vegetable commodity and a small Laguna pilot area. It will distinguish historical market-directory information from current buyer offers and will test the proposed workflow with farmers, buyers and a cooperative or market coordinator.

## Target Users Customers and Market

The primary beneficiaries are smallholder vegetable farmers who need practical selling alternatives for a specific harvest. Cooperative or farmer-association coordinators are an initial assisted-use channel, particularly for members who prefer help entering information or checking offers.

Participating buyers may include vegetable traders, restaurant suppliers and processors with explicit crop, grade, volume, receiving and payment requirements. The first pilot area will be chosen according to access to willing participants; Laguna is the proposed starting point, subject to validation.

## Proposed Solution and Value Proposition

AniWhere is a market-discovery application with AniPlan, an explainable harvest-allocation feature. A farmer enters the crop, quantity, location and availability, with grade and delivery preferences where relevant. AniPlan checks buyer compatibility and compares feasible allocations across up to two selling destinations, showing the amount each buyer can accept, estimated transport and other selling costs, payment timing and any unallocated harvest.

A small optional pooling workflow will allow up to three farmers to propose contributions toward one buyer's minimum order through a fixed aggregation point. It will show each participant's estimated proceeds and transport share and reject modeled arrangements that leave a participant worse off than their documented individual alternative. Participants and the buyer must confirm the arrangement.

If an offer expires or a buyer withdraws, AniPlan will recalculate the uncommitted portion and explain the revised options. Each plan will include a readable decision summary with input timestamps, deductions, assumptions and confirmation requirements.

The proposed distinction is the integration of whole-harvest planning, transparent participant economics and cancellation replanning in a small Philippine market-discovery workflow. Marketplaces, aggregation and cost calculators already exist; AniWhere will evaluate whether this integrated decision experience is useful to its pilot users. Estimates will be labeled sale proceeds after selling costs, rather than full farm profit or guaranteed income.

## Prototype and Technical Execution Strategy

Our three-member team will build a software-only web prototype over seven days. The initial scope is one crop, a small local buyer directory, no more than six offers per planning scenario, up to two destinations for the focal farmer, and one optional pool with a fixed hub.

The proposed stack is React and TypeScript for the interface, Leaflet for location display, FastAPI for the backend, and SQLite or an already-familiar PostgreSQL setup for persistence. A deterministic planner or OR-Tools will apply crop and grade compatibility, available quantities, buyer minimums, offer expiry, timing and selling-cost rules. Route estimates will be separated from editable transport quotes.

The core demonstration will enter a harvest, compare complete selling plans, show a bounded pooling proposal and recalculate after a buyer withdrawal. We will validate quantity conservation, buyer-capacity limits, transparent cost allocation and cancellation behavior. An accessible list and locally saved last-known plan will support map or connectivity failures, with stale information labeled.

Historical agency directories and price reports will provide contextual references. Current pilot demand will require timestamped buyer or coordinator input. Synthetic demonstration offers will be clearly labeled. Payments, automated negotiation, nationwide dispatch, price forecasting and automated produce grading are outside the first prototype.

## Business Model

AniWhere will initially test a cooperative-assisted model. Farmers could access basic discovery and plan viewing without a fee, while cooperatives or aggregators could subscribe to tools for maintaining offers, planning member harvests and reviewing allocations. Buyer tools for recurring requirements may provide an additional subscription option after demand is validated. Subscription pricing and willingness to pay remain research questions.

Potential partners include a farmer cooperative or association, a municipal agriculture office, participating buyers and local transport providers. These are proposed relationships, not established partnerships. AniWhere will support their existing physical handling and confirmation processes rather than operate warehouses or a vehicle fleet.

The project will begin with one crop and a small participant network, then expand after verifying data freshness, repeated use and operational value. Pilot evaluation will track feasible selling options, planning time, confirmed allocations and actual proceeds after selling costs. Recommendations will remain independent of paid placement so users can understand why an option is selected.

## Research references for the team

These support the framing and competitor comparison; they are not proof of AniWhere's outcomes. Remove or reformat this optional section if the organizer requires only the original template fields.

- [DA Region 10 market-matching and cooperative aggregation announcement](https://cagayandeoro.da.gov.ph/index.php/agri-10-oic-ggmc-ink-moa-to-boost-farmers-market-access-through-digital-platform/)
- [DA CALABARZON investment guide with historical buyer and trading-area leads](https://calabarzon.da.gov.ph/wp-content/uploads/2023/12/11282023-Investment-Guide-For-Selected-Agricultural-Commodities-in-CALABARZON-Booklet.pdf)
- [SARE research on farmer transport collaboration and transparent cost sharing](https://projects.sare.org/project-reports/onc20-070/)
- [Philippine market-choice modeling preprint](https://arxiv.org/abs/2505.06323)
- [TABO public product description](https://www.taboph.com/)
- [Ani Market public product description](https://animarket.ph/)
- [Buzzar public product description](https://buzzarr.com/)

This is an editable planning draft, not a submitted application. The template provides no judging weights. Confirm the organizer's deadline, format, code-reuse rules and actual prototype requirements before submission.
