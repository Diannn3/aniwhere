# AniWhere architecture and one-week build plan

Prepared 17 September 2026 for three builders. Status: implementation plan; application code has not been created in this pass. Read alongside `AniWhere-uiux-plan-2026-09-17.md` and `AniWhere-research-sourcebook-2026-09-17.md`.

## 1. Product decision and success criteria

AniWhere is a farmer market-discovery application. A farmer describes a harvest, explores reachable places, sees why each option may or may not fit, compares up to three options, and contacts a buyer or outlet before travelling.

The central question is **“Can I sell here?”** A useful answer combines crop, quantity, timing, public contact information, distance, and any supported buying terms. The map is the spatial view of those answers.

Confirmed constraints: all-Laguna scope; tomato, eggplant and calamansi for detailed matching; other commodities may be browsed with an explicit limited-information state; three builders; one-week prototype; software only; guest farmer access; English first with a Filipino switch; the seven supplied colors; polished homepage plus a focused application; public-source initial directory. Logo and final visual direction remain open for the user's selection.

The demo succeeds when someone can enter a harvest, identify the difference between full/partial/unknown fit, compare actual offered quantities, understand missing costs, and find a clear contact action without an account. The team can explain where every displayed fact came from. A polished screenshot alone is not that demonstration.

The prototype does not include payments, orders, inventory reservations, pooled harvest allocation, vehicle dispatch, a general farm-management suite, automated market-price predictions, or an LLM making selling recommendations. The archive's AniPlan direction is superseded.

### Defensible differentiation

The claim is a focused and inspectable workflow, not “the first marketplace for farmers.” TABO and Sakahon already demonstrate substantial nearby territory. AniWhere's pitch should demonstrate fit explanations, uncertainty, accepted quantity, comparison with stated costs, and contact preparation in one short flow. Validate the usefulness of that combination with farmers; do not invent adoption or income results. Competitor evidence and limits are in the sourcebook.

## 2. System architecture

Build one repository and one deployable web application. Use the existing public [Diannn3/aniwhere](https://github.com/Diannn3/aniwhere) repository, verified empty during this pass. Reinspect it before scaffolding because another agent may have begun work. Keep UPPETITE, RoomTBA and BetterSantaCruz read-only as upstream references.

```mermaid
flowchart TD
  Home[Astro homepage and place pages] --> App[Svelte discovery and comparison]
  App --> Domain[Pure fit and cost functions]
  App --> Public[Astro public read endpoints]
  Public --> DB[Supabase PostgreSQL and PostGIS]
  Buyer[Buyer draft editor] --> Auth[Astro authenticated actions]
  Admin[Admin review and publication] --> Auth
  Auth --> RLS[Verified session and row policies]
  RLS --> DB
  App --> Map[Lazy map adapter]
  Map --> Tiles[Permitted hosted tiles]
  App --> Route[Route endpoint on explicit request]
  Route --> ORS[openrouteservice]
  Demo[Explicit demo route and fixtures] --> Domain
```

### Stack and boundaries

| Layer | Decision | Reason |
|---|---|---|
| Pages/server | Astro, TypeScript, server adapter for Vercel | Matches inspected local expertise; static marketing pages with small server endpoints and protected editors. No separate Express service. |
| Interactive UI | Svelte 5 | Reuses familiar UPPETITE/RoomTBA patterns without a second UI runtime. |
| Styling | Tailwind 4 plus global semantic tokens | Implements the named UI/UX guidance and palette consistently. |
| Accessible primitives | Bits UI and selected shadcn-svelte source components | Dialogs, selects and focus handling; import only components actually used. |
| Icons | Lucide's Svelte package | One coherent outline family, accessible names on actions. |
| Data | Supabase PostgreSQL with PostGIS | Relational source/demand records plus geographic filtering and authenticated access. PostgreSQL and Postgres refer to the same database. |
| Validation | Zod at API and import boundaries | Reject invalid records before they influence fit or price arithmetic. |
| Fit/calculation | Small pure TypeScript functions | Deterministic, explainable, unit-testable, reusable by real and demo views. |
| Maps | MapLibre first, Leaflet fallback at Day 1 budget gate | Existing map expertise, with a defined performance escape route. Only one ships. |
| Routes | Hosted openrouteservice behind a server endpoint | Road distance is requested for a selected option, not calculated for every result. |
| Tests | Vitest, component tests, Playwright with axe | Domain boundaries, database policies, and real browser flows. |

Use the inspected UPPETITE generation as a compatibility starting point: Astro 7.2.x, Svelte 5.56.x, TypeScript 6.0.x and MapLibre 6.2.x. Resolve and pin compatible exact package versions with one package manager and committed lockfile during Day 1. This is not a direction to float on `latest` or copy every dependency. Use npm for the new app and a Node version supported by the chosen Astro/hosting adapter. Check their engines before choosing the CI version.

### Map renderer gate

The named UI/UX Engineer guidance sets a total interactive JavaScript target below 300 KiB gzip. Local MapLibre 6.2.0 production modules measure about 275.4 KiB gzip before application code. Do not call this budget satisfied by excluding its worker or lazy chunk.

On Day 1, build a representative discovery slice with three results, filters, sheet and map. Measure all JavaScript fetched to make that route fully usable, counting unique modules once and including the worker. If total compressed JavaScript exceeds 300 KiB after removing unused code, use Leaflet for v1 through the same map adapter. Retain MapLibre research as a later option; do not carry both renderers. Marketing homepage target is under 75 KiB and the list-only discovery target under 120 KiB. These are proposed gates to test, not achieved measurements.

### Proposed structure

```text
src/
  pages/                 home, explore, places, compare, demo, buyer, admin, api
  components/
    ui/                  selected accessible primitives
    harvest/             crop, quantity, location and availability inputs
    explore/             results, map adapter, detail panel, filters
    compare/             aligned comparison and entered-cost controls
    buyer/               draft and offer status controls
    admin/               source review and publication controls
  lib/
    domain/              types, crop aliases, fit, money, freshness
    data/                public repository adapter and demo fixture adapter
    server/              auth, validation, database reads and mutations, routes
    map/                 renderer adapter and provider configuration
    i18n/                English and Filipino dictionaries
    state/               URL parser, session state, versioned local drafts
  styles/                global design tokens and permitted base rules
data/
  reference/             versioned Laguna municipality metadata
  demo/                  fictional places/offers and explicit scenario date
supabase/migrations/     schema, grants, policies, publication function, indexes
tests/                   domain, policy, browser and accessibility checks
docs/                    decisions, source register, QA report, demo script
THIRD_PARTY_NOTICES.md
```

## 3. Information architecture and routes

| Route | Responsibility |
|---|---|
| `/` | Polished homepage, working harvest form, clear path to discovery. |
| `/explore` | Guest map/list, harvest context, fit explanations, filters, saved places. |
| `/places/[slug]` | Server-rendered public outlet details, sources, current offer, contact actions; independently shareable. |
| `/compare?places=...` | Up to three real place IDs. Recompute fit using the current local harvest. |
| `/demo` | Explicit fictional scenario using the same domain functions and UI components. Visibly labeled throughout. |
| `/buyer` | Authenticated assigned buyers manage offer drafts and request updates. |
| `/admin` | Administrators inspect sources, review submissions, publish or withdraw records. |
| `/about-data` | Explain coverage, source dates, current demand, approximate distances and corrections. |
| `/privacy` | Explain local draft storage, location handling and service providers. |

Language is `en` by default; `?lang=fil` selects Filipino and persists the choice locally. A locale switch keeps the current page and harvest. Use `lang="en"`/`lang="fil"` correctly and locale-aware Philippine-peso/date formatting. Keep the brand untranslated.

Persist non-sensitive navigation state in the URL: commodity, municipality, outlet type, view, selected place, sort, and comparison IDs. Keep precise coordinates, entered haulage quotes and unpublished notes out of URLs. Store the harvest draft locally with a version and “Clear saved harvest” action. Browser Back restores selection and filters. Sharing a comparison includes place IDs by default; it must not silently share the farmer's draft.

## 4. Minimal data model

Separate durable place identity, buyer-authored requirements, published offer snapshots, and evidence. Avoid a single `verified` boolean that implies all four are current.

| Entity | Minimum contents | Important rule |
|---|---|---|
| `commodities` | ID, English/Filipino name, aliases, detailed-match support | Aliases map to canonical IDs, not fuzzy AI guesses. |
| `municipalities` | PSGC, name, province, representative center, source release | A municipality center is not the farm's exact location. |
| `places` | ID, slug, name, type, role, municipality, public address/contact, optional geographic point, publication state | Distinguish buyer, trading venue, coop aggregation lead and other contact lead. A restaurant is not automatically buying direct. |
| `evidence_sources` | Source ID, publisher, URL, published/observed/reviewed dates, supported claim, reviewer, limitations | Preserve original URLs and dates; separate “we checked the page” from “buyer confirmed demand.” |
| `place_sources` | Place, source, supported field/claim | Allows different sources for existence, address, contact and commodity information. |
| `offer_submissions` | Place, author, commodity, quantity constraints, date window, price, fulfillment/payment notes, revision state | Buyer-owned drafts/revisions; never automatically public. |
| `buying_offers` | Published immutable terms snapshot, place, commodity, min/max quantity, dates, price basis, source/submission ID, validity/revocation metadata | Only admin publication changes the public terms. A revision replaces the previous active version transactionally. |
| `memberships` | User, place, role | Admin-assigned; no authority from editable profile metadata. |
| `audit_events` | Actor, record, action, timestamp, changed fields | Audit review and publication; do not log secrets or farmer coordinates. |

Store geographic points in WGS84 geography and add a GiST index. GeoJSON uses `[longitude, latitude]`. A missing or approximate geocode is explicit and never displayed as a precise entrance pin. Use municipality-level grouping until a specific address point is supported.

Store money as integer centavos and harvest mass as integer grams, presenting kilograms to users. V1 price basis is PHP/kg. Listings priced by sack/crate remain a contact lead until a sourced weight conversion exists. Missing min/max/price means unknown; it does not mean zero, unrestricted capacity, or no charge. If the buyer explicitly states no minimum, record that fact separately from missing information.

Buying terms include delivery/pickup, grade and packaging notes, receiving schedule, payment timing and applicable deductions where published. Free text is useful context, but it must not be converted automatically into a confident machine match.

## 5. Public interfaces and request flow

Keep the interface small enough to implement and inspect in a week.

```ts
type FitStatus = 'match' | 'partial' | 'confirm' | 'no_match';

type Harvest = {
  commodityId: string;
  quantityGrams: number;
  municipalityPsgc: string;
  availableOn?: string; // calendar date interpreted in Asia/Manila
};

type FitResult = {
  status: FitStatus;
  reasons: string[];          // translation keys plus structured values in code
  acceptedQuantityGrams: number | null;
  remainingQuantityGrams: number | null;
  conditionsToConfirm: string[];
  evaluatedAt: string;
};

type DistanceResult = {
  km: number | null;
  basis: 'straight_line' | 'road' | 'unknown';
  originPrecision: 'municipality' | 'approximate';
  calculatedAt?: string;
};
```

The exact serialized fields can remain ordinary JSON; the above distinctions are mandatory. A `null` accepted quantity must not be transformed into zero in presentation.

- `GET /api/places`: bounded, validated Laguna directory query; returns only published place fields and active published offers, source summaries, an `asOf` timestamp and coverage description. Maximum 50 items per page with stable continuation. No farmer coordinates are required for the baseline directory response.
- `GET /api/places/[id]`: public details and source history appropriate for the reader. Exclude private review notes and user IDs.
- `POST /api/routes`: selected destination ID plus an approximate origin, fixed supported driving profile; validate bounds, rate-limit, use a server-held provider key, timeout and return typed unavailable/approximate/route states. No arbitrary upstream URL accepted.
- Buyer submission and withdrawal-request actions: authenticated, scoped to membership, validated on the server. Never trust a client-supplied owner or publish flag.
- Admin review/publication actions: verified admin only, transactionally replace a published offer and create an audit entry. Field-level changes invalidate the prior review decision.
- `GET /api/health`: liveness without secrets, personal records or expensive provider calls.

For a 20–30-place seed, fetch a small bounded public dataset and derive fit locally with pure functions; use the same functions on server-rendered detail/compare views where applicable. PostgreSQL handles geographic filtering as the dataset grows. Avoid maintaining two separate matching algorithms.

Abort stale searches; the most recent valid form state wins. Loading a map must not reset the form or hide usable results. Server errors show retry actions and retain the user's entries. An unavailable database must not silently replace real results with fictional demo records.

## 6. “Can I sell here?” rules

The four states explain compatibility with published requirements; none guarantees a sale, reserved capacity, or final price.

1. Start with place role and evidence. A selling venue or historical cooperative lead without current direct-buying terms is **Contact to confirm**.
2. Evaluate a published, unrevoked offer valid for the requested date. No date entered means today in Asia/Manila and the interface says so. Expired, undated or superseded demand is insufficient for a current match.
3. Match the canonical crop. A documented restriction excluding that crop gives **Does not match**. Absence from an incomplete list gives **Contact to confirm**.
4. For known minimum and capacity, quantity at or above minimum and within capacity gives **Matches your harvest**. Quantity above capacity gives **Accepts part of your harvest** only if the buyer's stated terms allow the offered amount; show accepted and remaining mass.
5. Quantity below a known minimum, or a known incompatible receiving date, gives **Does not match**, with the specific reason. Unknown capacity or date rules give **Contact to confirm**.
6. Required grade, packaging, membership or delivery conditions that cannot be established remain explicit confirmation requirements. When a known required condition blocks eligibility, do not display an unqualified full match.
7. Price absence does not make an otherwise supported crop/quantity match false. Show “Price not posted.” Price presence does not prove crop/quantity compatibility.

Default ordering: full fit, partial fit, confirmation needed, then known mismatch; within each group sort by straight-line distance from the stated origin, then by recent source/offer timestamp, then stable place ID. Allow an explicit distance sort. Do not bury results because prices are missing, and do not make a paid placement appear to be a better match.

For other commodities, show directory browsing and contact leads. Do not extrapolate tomato rules to every crop. Record unit/grade limitations before adding a new detailed-match commodity.

## 7. Comparison and cost calculations

Compare a maximum of three options. Show the quantity each option can take, price basis, gross amount for that quantity, entered or supported transport charge, known selling deductions, remaining harvest, payment timing and confirmation requirements.

Use: `gross = accepted quantity × posted price`; `amount after entered costs = gross − entered transport − entered selling deductions`. Display missing inputs explicitly. Offer an editable transport-quote field first; deriving distance is not deriving a vehicle quotation. Zero transport is valid only if entered or supported, for example a confirmed free buyer pickup.

Do not call this profit or net farm income: growing costs, loss, rejection and other expenses may be absent. Do not invent spoilage rates, per-km tariffs, round-trip multipliers, commissions or loading fees. The interface should label a partial calculation as “After entered transport only” or “After the costs entered.” No automated best-option badge in v1.

### Reproducible fictional demo

Use a clearly labeled fixed scenario, dated 17 September 2026, with fictional organizations and supported fixture terms. Never attach invented prices to a real named business.

| Option | Accepted from 100 kg | Sample price | Gross | Entered transport | Amount after transport | Unplaced harvest |
|---|---:|---:|---:|---:|---:|---:|
| Sample Cooperative A | 100 kg | PHP 24/kg | PHP 2,400 | PHP 200 | PHP 2,200 | 0 kg |
| Sample Buyer B | 100 kg | PHP 27/kg | PHP 2,700 | PHP 650 | PHP 2,050 | 0 kg |
| Sample Processor C | 40 kg | PHP 30/kg | PHP 1,200 | PHP 120 | PHP 1,080 | 60 kg |

This demonstrates why unit price, accepted volume and trip cost need to be read together. C is not comparable to a whole-harvest sale on gross total alone. Add separate fixtures for expired terms, unknown quantity, missing price, unsupported unit and below-minimum quantity. Keep the demo date explicit rather than automatically making old fixture offers appear newly updated.

## 8. Geography, providers and reliability

The origin defaults to a chosen Laguna municipality's representative center. Label distances accordingly. Optional device location is requested only after a clear user action, reduced to an approximate grid before leaving the device, and kept out of persistent storage/logs. The municipality route remains usable when permission is denied.

Use a configured MapTiler style with correct attribution and domain restrictions for the non-commercial prototype, subject to the account's current terms. Choose a map style with legible roads and subdued POIs; style the layers with the AniWhere palette where permitted. Allow map panning, but explain that published results cover Laguna. Do not inherit UPPETITE's tight campus bounds or decorative terrain.

Load the map on demand on mobile; desktop can load it after results appear. Preserve an equivalent result list, buttons for zoom/recenter, and accessible place links. Cluster nearby pins using the renderer's available capabilities without adding a clustering library solely for 30 records.

Calculate a road route only when a person opens an option and requests it. Routing has a short timeout and never blocks contact details. Use a bounded cache for approximate origins and destinations where provider terms permit. Show straight-line distance on failure and explain its basis. Road output is an estimate, not real-time traffic, truck clearance, road safety, or a transport price. Keep municipal-center routes labeled approximate.

Do not use public Nominatim for autocomplete. Bundle the small municipality reference list. Do not bulk-prefetch OSM tiles or promise offline maps. Local saved place IDs and the user's own draft are sufficient for v1. A later offline snapshot must carry `downloadedAt` and re-evaluate expiry when reopened.

## 9. Access control, privacy and publication

Farmers browse as guests. Buyer/admin accounts are invited for the prototype. Use Supabase Auth with the server-side cookie integration and verified identity claims; checking that a session object exists is insufficient. Use immutable membership records for authorization, not client-editable user metadata.

Enable RLS and explicit grants on every exposed table. Anonymous users can read published public records only. Buyers can read/write their own submissions for assigned places; they cannot change membership, sources, published snapshots or audit events. Administrators can review and publish. Keep internal reviewer notes and account roles out of public responses.

Publication is a narrow server/database action that checks admin authority, the submission version and source review, then replaces the active terms and records the change in one transaction. Any privileged SQL function uses an explicit empty/fixed search path, checks the authenticated caller, and has narrowly granted execution. Prefer invoker behavior elsewhere; ensure public views cannot bypass RLS. Never put a service-role key in client code.

Validate same-origin authenticated mutations, return safe errors, render submitted content as text, accept only supported contact URL schemes, and rate-limit expensive route requests. No arbitrary URL fetching from buyer-provided input. Secrets live in environment configuration and stay out of the public repo and screenshots.

Store only public business contacts for discovery. Do not expose personal details copied from unrelated records. Contact actions open the user's phone or chosen public channel; the application does not send a message automatically. Do not log farm coordinates, quantities or draft messages in analytics.

## 10. Directory acquisition and operating model

Aim for 20–30 reviewed Laguna places if evidence supports them; publish fewer rather than pad the map. Cover different municipalities and outlet types where reliable records exist. This is a coverage target, not a promised count of active buyers.

For each candidate: capture original source URL/date; classify whether it buys, hosts selling, aggregates for members or is only a lead; confirm the public location/contact; record what is known about crop/quantity; set a review date; publish only supported fields. Two team members should inspect ambiguous entries before publication. A government mention of a one-day KADIWA event is not a permanent opening schedule.

Real-mode directory records and fictional demo fixtures are separate datasets. Initially, many real records may correctly show “Contact to confirm.” Current offers appear only when a public, dated source actually contains purchase terms or an authenticated representative later supplies them and an administrator reviews them.

Demand expires by its stated validity window and is evaluated at read time. Do not rely on a cron job to make expired offers disappear. For a price/quantity snapshot without an explicit expiry, the prototype's conservative policy is a maximum 24 hours from the source's actual update time; missing update time means contact-only. This 24-hour rule is a product assumption to validate, not an industry standard.

Place-contact review is separate: display the actual reviewed date; flag for admin recheck after 30 days, and after 90 days show “Contact details may need updating.” These cadences are team policies, not proof that a business closed. Rechecking an unchanged old web page does not make its buying demand new.

## 11. One-week work allocation and cut order

| Day | Builder 1: experience | Builder 2: data and security | Builder 3: map, evidence and QA | Exit condition |
|---|---|---|---|---|
| 1 | Tokens, harvest form, one result, comparison skeleton | Schema sketch, public repository adapter, domain contracts | Inspect reuse licenses; map bundle spike; first source records | One vertical slice; renderer fixed by measured budget; no dependency ambiguity. |
| 2 | Desktop/mobile result list and detail | Fit function, freshness, validation and unit cases | Municipality data, map/list synchronization, first reviewed places | Same harvest produces consistent fit in list/detail/demo. |
| 3 | Comparison, cost inputs and contact preparation | Supabase migrations, grants/RLS, auth | Map failures, approximate distance, source presentation | Real directory and fictional demo remain visibly distinct. |
| 4 | Buyer draft editor | Admin review/publication transaction and policy tests | Optional road-route integration; dataset review | Assigned buyer submits; admin publishes; expired/revoked terms stop matching. |
| 5 | Selected homepage direction, mobile polish, translations | Error handling, rate limits, public response review | Keyboard/a11y checks, six viewports, asset and JS budgets | Core experience complete; no new feature expansion. |
| 6 | Fix usability friction | Fix domain/security failures | Full browser scenarios, content and attribution review | All required checks pass or a failing feature is removed with disclosure. |
| 7 | Pitch walkthrough, final screenshots | Deployment configuration and smoke checks | Demo rehearsal, fallback dataset, QA report | Reproducible demo and honest limitations ready for review. |

Cut in this order if time slips: decorative motion, automated road routes, additional commodities, advanced saved-place/offline features, then buyer self-service (admin-entered reviewed terms can support the prototype). Retain fit explanations, real/demo separation, comparable quantities, contact actions, mobile list, source dates and basic publication security. A selected landscape homepage is implemented with an optimized static asset for this week.

## 12. Acceptance tests

### Domain and evidence

- Exact minimum/maximum quantities, partial capacity, below-minimum, invalid/zero/negative/very large inputs, decimal kilograms, and rounding at centavo boundaries.
- Crop aliases in both languages; unsupported commodity; known exclusion versus absent information; membership/grade conditions that still require confirmation.
- Offers valid today, not yet valid, expired exactly at the boundary, revoked, superseded and missing source timestamps. Use Asia/Manila calendar dates consistently with UTC instants.
- Missing price still permits supported non-price fit. Unknown transport stays unknown. Partial-sale calculations show remaining mass. The three fictional arithmetic examples reproduce exactly.
- Source review does not refresh old demand; deleted/unpublished places disappear from public reads; a missing geocode is not plotted at zero coordinates.

### Access and API

- Guest cannot read drafts/private notes or mutate data. Buyer A cannot edit Buyer B's place or promote a submission. Buyer cannot assign itself admin through metadata.
- Non-admin cannot invoke publication. Stale submission version cannot be approved. Published terms and audit entry update atomically.
- Route endpoint rejects arbitrary destinations/URLs, malformed coordinates and excessive requests; provider timeout/quota failure returns a usable state.
- Public responses and browser bundles contain no service key, reviewer notes or exact farm coordinates. No sensitive draft state appears in share URLs.

### Browser and accessibility

- Guest input → results → map/list → detail → compare → contact; browser Back/Forward preserves meaningful state.
- Location denied, slow network, database error, no matches, unknown-only results, map/WebGL failure, expired offer while comparing, stale saved IDs and long business names.
- Keyboard operates every action; drawer/modal focus is intentional and restored. Expanded sheet does not fight page scrolling; buttons provide alternatives to dragging.
- EN/FIL switching, text zoom, reduced motion, forced colors and coarse pointer. Check widths 375, 390, 414, 768, 1024 and 1440; also examine 320px reflow.
- Required attribution remains visible around sheets and safe areas. Mockup artwork never functions as a route map.

### Performance and release evidence

- Production bundle report meets the JavaScript budgets, including map worker/chunks. If it fails, execute the predefined renderer fallback.
- Target LCP ≤2.5 seconds, CLS ≤0.1 and INP ≤200 ms in appropriate measurement contexts; report lab method/device/network and do not invent field percentiles from a local run.
- Type checking, production build, meaningful domain tests, RLS tests and browser scenarios pass. Report any skipped scenarios explicitly.
- Test deployed environment keys, callbacks, map domain restrictions and required attribution. Keep a local reproducible `/demo` for presentation failures; do not claim it is live market data.

The implementation deliverables are the app, migrations, seed/source register, third-party notices, environment example, test results, known-limitations note and a short demo script. This document itself is planning evidence only.
