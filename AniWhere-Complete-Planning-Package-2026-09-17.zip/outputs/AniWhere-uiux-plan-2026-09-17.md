# AniWhere UI/UX plan

Prepared 17 September 2026. This plan covers the homepage and farmer/buyer/admin experience. The three generated images are art-direction previews; the application has not been implemented or tested. The logo remains undecided, so all previews use a temporary text wordmark.

Read with `AniWhere-architecture-and-build-plan-2026-09-17.md` for data/rules/security and `AniWhere-research-sourcebook-2026-09-17.md` for inspected repositories, websites, discussions and source limitations.

## 1. Design objective and applied guidance

AniWhere should feel like a carefully designed agricultural product: warm, confident and geographically grounded. Its working interface must help a farmer decide whom to contact without learning a dashboard. Visual sophistication comes from the map, hierarchy, typography, spacing, clear comparisons and considered transitions.

Use the named [UI/UX Engineer guidance](C:/Users/Dian/Documents/Vaults/Fensalir/systems/agents/13_ui_ux_engineer.md), [UI/UX Pro Max](C:/Users/Dian/.agents/skills/ui-ux-pro-max/SKILL.md), and [current Web Interface Guidelines](https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md). Their useful shared requirements are semantic controls, strong contrast, deliberate typography, visible focus, reliable mobile behavior and restrained motion. The Svelte addendum supports Bits UI/shadcn-svelte; React-specific examples do not require a React runtime.

The Pro Max search returned a generic organic palette and horizontal-scroll idea. Those do not override the user's palette or a farmer's linear search task. Use native vertical scrolling, a functional form, and a coordinated map/list. A 44–48px control target is this product's usability choice; WCAG 2.2 AA's minimum-target criterion has a different threshold and exceptions.

## 2. Three generated visual directions

All previews use the same English headline, crop/quantity/location fields, and “Can I sell here?” proposition. They do not contain a selected logo. Full generation prompts and inspection notes are in [generation-prompts.md](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/generation-prompts.md).

| Direction | Preview | Character and implementation |
|---|---|---|
| A — Editorial map | [Open image](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/A-editorial-map.png) | Oversized sans typography, cream space, custom map composition. Best direct expression of discovery. Recreate any operational map from real data; remove the generator's extra small slogan. |
| B — Farm photography | [Open image](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/B-farm-photography.png) | Human agricultural story, serif display type and documentary framing. The generated person is fictional; a real partner story needs a licensed/consented photograph. |
| C — Immersive landscape | [Open image](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/C-immersive-landscape.png) | Dramatic geographic setting and overlay copy. Use an optimized static hero in week one, with strong text contrast and a distinct mobile crop. |

Recommendation pending the user's selection: A for the main product identity, with B-style photography in an optional lower story section. C can be used without a terrain engine; an atmospheric still does not require a WebGL homepage. The core application specification below is shared by all directions. Do not treat this recommendation as a selected logo or final user approval of A.

### How the inspiration informs the work

- Farm Minerals: confident scale, an earthy limited palette and one clear subject driving the narrative. Adapt that discipline to harvest-to-market discovery.
- Explore Primland: memorable geography and selected locations. Its cinematic introduction is reference material; AniWhere's form stays immediately available.
- Beerenberg: agricultural people/product storytelling and provenance. AniWhere translates provenance into sources and dates, not unearned trust seals.
- Made for Spain & Portugal and Roadtrips South Australia: controlled geographic exploration and place context.
- Airbnb's documented search flow: preserve search context, synchronize the map and list, and reveal specific details before the contact action.

Award classifications, live inspection coverage and links are documented in the sourcebook. Copy composition principles and interaction ideas; create original assets and layouts.

## 3. Palette and semantic tokens

Keep all seven supplied colors. Assign roles instead of spreading them equally across every screen.

| Color | Hex | Primary role |
|---|---|---|
| Field Olive | `#597928` | Primary action background, selected outline, prominent brand accent. |
| Young Leaf | `#91AC67` | Field/map areas, supportive fills and illustrations with dark foregrounds. |
| Soil Brown | `#6E3511` | Confirmation/warning emphasis, harvest-related accent, selected metadata. |
| Rice Cream | `#FCECD8` | Broad background bands and soft contrast behind sections. |
| Warm Surface | `#FFFDF8` | Main reading surfaces, form fields and dialogs. |
| Field Ink | `#20251E` | Body text, headlines, strong borders and essential data. |
| Route Blue | `#4E7380` | Route line, distance-related accents and links on Warm Surface. |

CSS variables should name both colors and purposes: `--color-field-olive`, `--surface`, `--surface-soft`, `--text`, `--action`, `--action-text`, `--border`, `--route`, `--focus`, `--warning`. Derive subtle borders from Field Ink with measured alpha; avoid an unrelated gray palette.

### Contrast measurements

Computed from the supplied sRGB hex values using the WCAG relative-luminance formula. These are solid-color pairings; photographs, translucency and hover states require their own checks.

| Foreground | On Warm Surface | On Rice Cream | Normal text decision |
|---|---:|---:|---|
| Field Ink | 15.36:1 | 13.48:1 | Use freely for core text. |
| Soil Brown | 9.47:1 | 8.31:1 | Suitable for text on both. |
| Field Olive | 4.93:1 | 4.33:1 | Suitable on Warm Surface; use Field Ink for small text on Rice Cream. |
| Route Blue | 5.05:1 | 4.43:1 | Suitable on Warm Surface; do not use for small unmodified text on Rice Cream. |
| Young Leaf | 2.49:1 | 2.18:1 | Fills and decoration; not normal text on either background. |

Primary buttons use Warm Surface text on Field Olive. Status meaning is written and icon-supported; color never carries it alone. Use Brown/Ink for “Contact to confirm,” an outline question icon, and a plain reason. A mismatch can use a minus icon and text without introducing a new red palette.

## 4. Type, layout and components

### Typography

- A/C: Manrope for display and headings, Source Sans 3 for forms/body/data.
- B: Source Serif 4 for homepage display headings, Source Sans 3 for homepage body; the working app retains the shared Manrope/Source Sans 3 system.
- Self-host only needed WOFF2 subsets/weights. Preserve font licenses: [Manrope](https://github.com/google/fonts/blob/main/ofl/manrope/OFL.txt), [Source Sans 3](https://github.com/google/fonts/blob/main/ofl/sourcesans3/OFL.txt), [Source Serif 4](https://github.com/google/fonts/blob/main/ofl/sourceserif4/OFL.txt), all checked as SIL OFL 1.1.
- Hero: approximately 44–52px on phones and 72–96px on large screens, with `clamp()` and deliberate line breaks at tested widths.
- Application page title: 28–36px; section title 22–28px; result title 18–20px; body and input text 16–18px; secondary metadata 14px. Keep the key price, quantity and fit labels out of tiny caption text.
- Body line-height around 1.5; reading text limited to 65–75 characters. Use tabular numerals for aligned monetary/quantity values. Use proportional, readable labels around them.

### Geometry

- Use a 4px base with primary gaps at 8, 12, 16, 24, 32, 48 and 64px.
- Homepage: max-width around 1280px, 24–48px desktop gutters, 16–20px mobile gutters.
- Desktop app at ≥1024px: approximately 400px result column and flexible map; 16–24px interior padding. A selected detail replaces the list column or uses a contained panel, avoiding an unreadable third column.
- Below 1024px: list and map are explicit modes. Default to list on initial mobile visit to make useful information available quickly; persist the user's preference. Map is one tap away.
- Controls at least 44px high, principal actions 48–52px; sensible 8px separation. Use safe-area padding on fixed bottom actions.
- Radii: 8px controls, 12px panels, 20px mobile sheet top corners; pills only for real toggles/chips. No large radius on every text block.
- Depth: subtle separation only for sheets, dropdowns and focused overlays. Result rows use dividers and space rather than stacks of floating cards.

### Shared component inventory

Build `HarvestForm`, `CropSelect`, `QuantityInput`, `MunicipalitySelect`, `HarvestSummary`, `FitLabel`, `ReasonList`, `OfferSummary`, `SourceDetails`, `ResultRow`, `PlacePanel`, `MapView`, `ViewToggle`, `CompareTray`, `ComparisonView`, `CostInputs`, `ContactPreparation`, `LanguageSwitch`, `StatusNotice`, and `DemoNotice`.

Use native inputs where practical, Bits UI for necessary complex behavior, and semantic HTML for reading surfaces. Source details belong in an accessible disclosure, not a hover tooltip. In the generated images the quantity resembles a select; actual implementation uses a numeric input with a permanent `kg` suffix.

## 5. Homepage: discovery begins above the fold

The homepage is a polished entrance to the working product, with a form that submits to real discovery. It must not become a separate presentation that users must scroll through to find the app.

### Page order

1. Header: text wordmark, Explore markets, How it works, For buyers, EN/FIL, and Find buyers. Keep navigation concise on mobile.
2. Hero: selected visual direction, headline “More places for your harvest.”, supporting text “Discover nearby buyers. Compare your options. Know who to call.” and harvest form.
3. “Can I sell here?”: explain crop, quantity and confirmation using one meaningful example, not generic feature cards.
4. A small product demonstration with a plainly labeled sample scenario and a link to `/demo`. Use the real components when possible so the product and presentation agree.
5. Coverage/data explanation: “Explore selling options across Laguna,” followed by accurate coverage/source information. Do not display invented active-buyer counts or “live prices” claims.
6. Buyer invitation: explain how an invited representative can submit buying requirements. Public registration is not required in week one.
7. Footer: About the data, Privacy, source/attribution credits and a practical correction route.

Do not add a partner-logo strip, farmer testimonials, impact numbers, awards, ratings, a decorative “trusted” shield, or a social-proof counter without supporting evidence. Keep photography rights and geographic accuracy visible in the internal asset register.

### Hero behavior by direction

For A, the hero uses original static cartographic art with limited decorative detail. If an example marker is interactive, its visible sample label and associated content make its purpose clear. The actual discovery map loads only inside the application.

For B, the image has an intentional mobile crop, explicit intrinsic dimensions and a rights record. The pictured person is not presented as a real AniWhere user unless that is established.

For C, keep the text on a stable dark scrim and place search fields on an opaque surface. Use a still image first. Animated scenery is a later enhancement that must meet the existing budget and reduced-motion rules. No audio gate or loading screen.

## 6. Farmer journey and screen specification

### Harvest entry

Required inputs are commodity, positive quantity in kilograms, and municipality. Default available date is today and state it clearly; an optional date control changes it. Tomato, eggplant and calamansi are prominent, with an “Other crop” directory option. Do not request farmer name, phone number, email or account creation to browse.

Inputs have persistent labels, a clear unit and useful examples. Validate on submit and after a corrected field changes, not on every keystroke before the user has finished. Keep entered values on error and focus the first failing field. Example: “Enter the harvest weight in kilograms.”

The municipality selector searches the bundled list locally. “Use approximate location” is optional and explains its purpose before opening the browser permission prompt. If denied, preserve the municipality choice.

### Results and map

```text
Desktop
┌ AniWhere   [Tomato · 100 kg · Laguna] [Edit]       EN/FIL ┐
├ [Outlet type] [Fit] [Distance sort] [Saved]              ┤
│ Results and selected details │                         │
│ Name · outlet role           │        Map              │
│ Fit + one-line reason        │                         │
│ Price / not posted           │  Selected marker ↔ row  │
│ Distance + basis             │                         │
│ [Details] [Compare]          │                         │
├ [2 selected for comparison]              [Compare]     ┤
└───────────────────────────────────────────────────────┘

Mobile list                          Mobile map
┌ AniWhere          EN/FIL ┐          ┌ Harvest summary    ┐
│ Tomato · 100 kg   [Edit] │          │                     │
│ Municipality · Today    │          │        Map          │
│ [Filters] [List | Map]   │          │                     │
│ Place name              │          │ [Zoom] [Recenter]   │
│ Fit + reason            │          ├ Selected place      ┤
│ Price · distance        │          │ Fit + key reason    │
│ [Details] [Compare]     │          │ [Expand] [Close]    │
│ Other results…          │          │ [Details] [Compare] │
│ [Compare 2]             │          └ Attribution visible ┘
└─────────────────────────┘
```

Every result begins with the place's name and actual role, then the fit label and reason. Next show accepted quantity, price or “Price not posted,” distance basis, and offer/source timestamp. Details and Compare are separate actions with clear names.

Selecting a list row highlights the corresponding marker; selecting a marker opens the corresponding panel. Distinguish selected state with shape/outline and text, not color alone. The map uses muted context and prominent result markers. Avoid seven competing pin colors for seven business types; use a restrained marker family and a simple role icon where needed.

Panning the map does not silently replace the result set. Show “Search this area” when geographic filtering would change; preserve the farmer's harvest. Provide “Show all Laguna options” to restore the provincial scope. Map failure leaves the list and contact actions functional.

### Four fit states

| Label | Visible example reason | Next action |
|---|---|---|
| Matches your harvest | “Listed for tomatoes, 20–150 kg, on your selected date.” | Inspect terms and confirm with buyer. |
| Accepts part of your harvest | “Listed capacity: 40 kg. You would have 60 kg remaining.” | Compare the partial option without implying full clearance. |
| Contact to confirm | “Tomatoes are mentioned; current quantity and price are not posted.” | Open contact preparation. |
| Does not match | “Minimum listed quantity is 200 kg; your harvest is 100 kg.” | Adjust quantity only if correct, or browse another option. |

These examples are copy templates. Real figures must come from valid records. Include a short explanation that matching checks stated requirements and the buyer must confirm acceptance.

### Place detail

Order content by decision priority: place/role, fit and reasons, valid buying terms, quantity/price basis, delivery or pickup requirements, payment timing, receiving schedule, approximate distance, source/updated details, and contact.

Show a specific claim when supported: “Business details checked on 17 Sep.” Do not use a universal “Verified buyer” badge when only the address was checked. A place being open is not equivalent to its receiving staff accepting a crop.

Allow an expandable “Why this result?” section with the crop/quantity/date checks and missing information. Source records remain reachable from the details, with the original publisher and date. Internal reviewer notes remain private.

### Mobile bottom sheet

Adapt RoomTBA's peek/expanded behavior. A peek shows the place name, fit, key quantity and Expand/Close actions. An expanded sheet fits within the available viewport and scrolls its contents. Dragging is optional; buttons and keyboard perform equivalent actions.

The peek is non-modal: do not trap focus or make the map inaccessible. The expanded detail dialog has an intentional focus target, a labeled close button, Escape handling and focus restoration. Avoid autofocus that opens the mobile keyboard. Account for the onscreen keyboard and safe-area inset. The sheet's scroll region must not steal upward/downward movement unpredictably.

### Comparison

Desktop uses aligned rows and a maximum of three option columns. Row order: accepted quantity, unplaced quantity, price basis, gross for accepted quantity, entered transport, other entered deductions, amount after those costs, pickup/delivery, payment timing, missing confirmations and contact.

On mobile show a one-field-at-a-time vertical comparison: for example, a “Quantity accepted” block lists A/B/C, then the price block lists A/B/C. This keeps values adjacent without a wide sideways table. Keep the option names repeated in an accessible way. Never require horizontal dragging to discover an essential column.

The comparison tray appears after the first selection and says how many are selected. A fourth selection produces a clear message to remove one first. Removing a place does not delete the harvest. If an offer expires while open, re-evaluate and show “Offer expired; contact to confirm.” Preserve the user's entered costs but mark the resulting calculation as incomplete until the terms are valid.

### Contact preparation

Provide a short editable message with commodity, quantity, intended date and the questions still unanswered. Example: “Hello, I have 100 kg of tomatoes available on 18 Sep. Are you accepting this quantity? What price, grade and delivery terms apply?” Use the chosen interface language.

Buttons: Call buyer, Open public contact page, Copy message. Present only actions supported by the published contact details. Do not silently send a message, invent a messaging account, or claim that a phone number is active. Keep grade, pickup, timing and payment questions visible so a farmer can call without using the message generator.

## 7. Buyer and administrator experience

The buyer screen is a focused editor. Show assigned outlet, crop, minimum/maximum quantity, acceptance dates, price or “not posted,” grade/packaging, pickup/delivery, payment timing and public contact. Explain which fields determine fit. Display the preview farmers will see before submission.

Use distinct states: Draft, Submitted for review, Published, Update requested, Expired, Withdrawn. Buyers save/submit updates; they do not press a control that suggests immediate publication when admin review is required. A changed draft should not silently modify a live offer. Allow a withdrawal request when an outlet is no longer buying.

The administrator screen is a review queue, not an analytics dashboard. Prioritize pending submissions, expired demand, unclear source claims and contact records due for review. A review displays original source, dates, proposed field changes, public preview and Publish/Return for correction/Withdraw controls. Show the scope of review: identity, contact, commodity requirements or price.

For the initial public-source pilot, the administrator can enter and review directory records directly. Real representative onboarding can be demonstrated with a test account and fictional outlet; that does not make the outlet an actual partner.

## 8. English and Filipino copy system

English is the first-visit default. Use a visible `EN / FIL` control; preserve all entered state when switching. Store strings in dictionaries, not hardcoded inside matching functions. Structured reason keys contain values that localization can place naturally.

| English | Draft Filipino |
|---|---|
| Your crop | Iyong ani |
| Quantity (kg) | Dami (kg) |
| Your municipality | Iyong bayan o lungsod |
| Available on | Kailan handa ang ani? |
| Find places to sell | Maghanap ng mapagbebentahan |
| Matches your harvest | Tugma sa iyong ani |
| Accepts part of your harvest | Bahagi lang ng ani ang kayang tanggapin |
| Contact to confirm | Makipag-ugnayan para makumpirma |
| Does not match | Hindi tugma sa iyong ani |
| Price not posted | Walang nakasaad na presyo |
| Compare options | Ihambing ang mga pagpipilian |
| Call buyer | Tawagan ang mamimili |
| From municipality center | Mula sa sentro ng bayan o lungsod |

These Filipino labels are working copy for review with a fluent speaker and intended users. Let buttons grow rather than shrinking translated text. Currency uses `PHP`/peso formatting consistently; units always accompany numbers. Use explicit dates and “as of” labels for older records. Never show “updated just now” because the page was fetched just now.

## 9. Loading, empty, error and trust states

| Situation | Required response |
|---|---|
| First visit | Working form and explanation; no forced registration or location prompt. |
| Search loading | Keep form and prior context visible; announce loading politely; prevent duplicate submissions. |
| No known current match | “No confirmed fit for this harvest yet.” Offer contact leads, changed location/date, or broader directory browsing. Do not claim no buyer exists. |
| Only public directory information | Keep places visible with contact-to-confirm reasons. Missing data is an honest result. |
| Unsupported crop | Explain limited detailed matching and allow directory browsing. |
| Missing price | Text label with no fake zero or empty currency symbol. |
| Missing/unknown transport | Editable quote input and an explicitly incomplete calculation. |
| No precise place coordinates | Municipality-level context with a visible limitation; retain address/contact. |
| Map unavailable | “Map unavailable. You can still use the list.” Retry without resetting the harvest. |
| Route unavailable | Retain straight-line distance with its label; offer contact/directions without a fabricated travel time. |
| Source/offer expired | Remove current-fit assertion, preserve dated context as historical only where useful. |
| Database unavailable | Explain retrieval failure and retry; optional clearly separate demo link, never an automatic data swap. |
| Demo mode | Persistent “Sample scenario — fictional buyers and offers.” Use fixed dates and sample-only contact actions. |
| Buyer validation failure | Inline message at the field, values retained, first invalid field focused. |
| Source disagreement | Contact-to-confirm or hidden disputed claim, plus an admin review task. |

Product labels such as “Sample scenario,” source dates and approximate distance are necessary for an informed decision. The anti-prompt-leakage rule does not justify hiding whether a price is fictional.

## 10. Motion and interaction specification

Use 150–250ms transitions for hover, selection and panel changes with a simple ease-out. Animate opacity/transform where appropriate; avoid `transition: all`, spring/bounce, delayed controls, cursor replacement and scroll hijacking. Normal page scroll remains native.

The application's memorable interaction is the linked result and map: selecting an option makes its location and requirements immediately understandable. A short route highlight may run once after an explicit selection. It must not imply a route has been calculated before the provider response exists.

On reduced motion, update selected state instantly and disable route drawing/pans that imply travel. On forced colors, use borders, system foregrounds and text states; preserve a full list alternative. On coarse pointers, remove hover-only reveals and make every action visible. No looping scenery in the week-one implementation.

Map movement responds to explicit selection; typing into a form must not constantly fly the camera. Keep the selected point clear of the sheet by using renderer padding. Preserve the user's chosen zoom when possible and provide a visible recenter action.

## 11. Asset and visual quality rules

Use real photographs only with an appropriate license or permission, recorded with source/creator/license/use. Do not lift photography or proprietary fonts from inspiration sites. Use generated assets as clearly understood concept/illustration material, not a fabricated customer story.

The generated screenshots contain complete interface text; do not use them as the actual webpage. Rebuild text, forms, controls and links in semantic HTML/Svelte. If extracting a decorative image is needed, create a proper art asset separately; do not rasterize the working UI.

The mockups' geography is illustrative. Recreate actual maps from the selected geographic source with correct attribution. Do not trace generated map labels into the operational dataset. Keep claims, photos and logos out of the product until the rights/evidence record is clear.

Use AVIF/WebP where suitable, explicit intrinsic sizes and responsive sources. Initial homepage image budget: approximately 250 KiB on mobile and 450 KiB on desktop; these are design targets, not measurements of the current PNG previews, which are larger. Prefer one principal image per viewport. Preload only the real critical image/font, lazy-load below-fold assets, and keep all essential copy outside imagery.

## 12. Review and acceptance process

### Design review

Review the selected direction at 1440px and 390px before extending it across every screen. Confirm that the harvest form is obvious, place/fit/quantity/price are readable in order, and the visual character belongs to agriculture and discovery. Check a real long outlet name, a partial fit, missing price and an expired offer rather than reviewing only an ideal filled screen.

### Browser checks

Check 375, 390, 414, 768, 1024 and 1440px widths as required by the named guidance; add a 320px reflow check. Test 200% zoom, long Filipino translations, phone keyboard, portrait/landscape changes, safe areas, Chrome desktop and Android, and Safari/iOS where a real device or appropriate browser is available. Report unavailable device coverage instead of implying it was tested.

Keyboard testing covers the full farmer flow, filter dialog, map controls, sheet expansion, comparison selection and buyer editor. Verify focus never hides behind the fixed tray and returns to the invoking control. Test the older MapLibre gesture report against the actual installed version and the Bits UI autofocus report in the composed sheet.

Run automated accessibility checks and manually inspect reading order, input labels, status announcements, color-independent meaning and forced colors. A clean axe scan is not a complete usability audit. Every critical map task must have a non-map equivalent.

### Task-based validation

If the team can recruit willing participants separately, test: “You have 100 kg of tomatoes; find two places you would contact and explain why.” Observe entry mistakes, whether partial capacity is understood, whether users mistake a reference price for an offer, and whether they notice missing transport costs. Record task completion and confusion without inventing income effects.

For the hackathon rehearsal, use teammates who did not build the screen if external participants are unavailable; label this as internal testing. Public-source-only data acquisition does not authorize outreach in this task. No messages were sent during research.

### Definition of UI completion

A screen is ready only when its normal, loading, empty, error, unknown-data and expired-data states are designed and exercised; mobile and keyboard actions work; text/color contrast passes; the map/list agree; sources and fictional data are clear; and the production asset/JavaScript budgets in the architecture plan are measured. Preserve screenshots and a concise QA report with failures, skips and fixes.

## 13. Selection handoff

The only visual decision intentionally awaiting the user is the homepage direction: A, B, C, or the recommended A with B-style photography below. Each preview has been generated and saved. The logo is also intentionally open. Work on the common data, domain rules, list/detail/compare behavior and accessibility contracts can proceed independently; do not lock a different visual direction on the user's behalf.
