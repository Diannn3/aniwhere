# AniWhere visual direction prompts

Generated 17 September 2026 with the built-in image-generation tool. These are concept previews, not implemented screens. The logo is undecided; the wordmark is a placeholder. All three images were visually inspected after generation. The photograph is synthetic and does not document a real farmer or partner. Maps and landscapes are illustrative and must not be used for directions.

## A — Editorial map

File: [A-editorial-map.png](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/A-editorial-map.png)

Observation: strongest connection to the discovery product. The generator added a small extra slogan; omit that slogan in implementation. Rebuild the map from appropriately licensed geographic data if locations are interactive. Do not treat generated map geometry as accurate.

```text
Use case: ui-mockup.
Create one exceptionally polished, high-fidelity desktop website design mockup for AniWhere, a Philippine farmer market-discovery product. Design direction A: EDITORIAL MAP. This is one flat website screenshot, landscape 1536 by 1024 composition, no device frame, no perspective, no moodboard collage. Premium award-caliber editorial art direction with functional clear UI.

Brand: wordmark text "AniWhere" only, no logo symbol because logo is not yet selected. Exact UI palette: Field Olive #597928, Young Leaf #91AC67, Soil Brown #6E3511, Rice Cream #FCECD8, Warm Surface #FFFDF8, Field Ink #20251E, Route Blue #4E7380. Mostly Warm Surface and Rice Cream, crisp Field Ink text, Olive primary controls. Warm restrained visual richness. Strong elegant contemporary sans serif typography, oversized confident headline, excellent grid alignment and whitespace. Flat refined surfaces, thin rules, minimal radius, no generic floating card clutter.

Navigation at top with AniWhere at left, "Explore markets", "How it works", "For buyers", "EN / FIL" and olive button "Find buyers".
Hero main headline exact: "More places for your harvest." Set over three generous lines at left. Supporting copy: "Discover nearby buyers. Compare your options. Know who to call." Right half is a bespoke beautiful FLAT cartographic artwork suggesting Laguna and Laguna de Bay: warm cream land, desaturated blue lake, olive field parcels, very subtle contour lines and three precisely plotted simple buyer markers connected with thin Route Blue route lines. Artistic map illustration, not an authoritative map. Map labels only "Calamba", "Los Baños", "Santa Cruz". One integrated clean mini panel on map: "Sample cooperative" and "Contact to confirm", plus a small visible "Illustrative map" caption. Avoid fake ratings and prices.
Below the hero, a wide horizontal crisp search form with labels and values: "Your crop" / "Tomato", "Quantity" / "100 kg", "Location" / "Laguna"; olive primary button "Find places to sell".
Bottom of screenshot begins a well-designed next section separated by a thin rule, title "Can I sell here?" with three compact parallel editorial columns: "Crop accepted", "Quantity fit", "Confirm before travel". Simple coherent outline icons and plain sentence fragments.
Make this feel like a finished premium startup website, exceptionally intentional and readable. No photography in this direction. No gradients, glassmorphism, 3D, badge row, fake metrics, testimonials, award marks, extra brands, ornamental logo, browser chrome or explanatory labels outside the website. All visible website copy in English.
```

## B — Farm photography

File: [B-farm-photography.png](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/B-farm-photography.png)

Observation: warmer and more personal. Replace the synthetic farmer with a properly licensed or consented photograph before presenting a real partner story. Use a numeric quantity input in code; the generated dropdown arrow is only a visual artifact.

```text
Use case: ui-mockup. Create one exceptionally polished, high-fidelity desktop website mockup for AniWhere, a Philippine farmer market-discovery product. Direction B: FARM PHOTOGRAPHY. One flat website screenshot, landscape 1536x1024 composition, no devices or perspective, no collage. Premium editorial design, powerful warm documentary photography, beautifully controlled typographic hierarchy and generous negative space. Wordmark "AniWhere" only, no logo symbol.
UI palette strictly: Olive #597928, Leaf #91AC67, Soil Brown #6E3511, Rice Cream #FCECD8, Warm Surface #FFFDF8, Ink #20251E, Route Blue #4E7380. Photograph retains natural realistic colors, no extreme teal-orange grading. Use clean warm cream background, olive controls, ink text.
Navigation: "AniWhere", "Explore markets", "How it works", "For buyers", "EN / FIL", olive button "Find buyers".
Hero is an original magazine-like split composition: large refined dark serif heading on generous cream LEFT 45%, warm documentary photograph RIGHT 55% within a precisely rectangular frame. Exact heading: "More places for your harvest." Supporting exact copy in clean legible sans serif: "Discover nearby buyers. Compare your options. Know who to call."
Photograph: an unidentifiable adult Filipino farmer in ordinary practical working clothes beside crates of freshly picked eggplants, tomatoes and calamansi at the edge of a lush lowland vegetable farm in Laguna, Philippines; grounded, dignified, candid late-afternoon natural lighting, 35mm documentary detail, visible hands and harvest, no staged corporate handshake or exotic rice terraces. No testimonial, person name, or implied real partner. It is a conceptual generated photo. Overlay a small elegant cream editorial caption at bottom of photo: "From your field to more possibilities."
Below hero put a wide bordered cream horizontal harvest form: "Your crop" / "Tomato"; "Quantity" / "100 kg"; "Location" / "Laguna"; olive button "Find places to sell".
Bottom begins an open, clean editorial section titled "Can I sell here?" followed by three equal clear short columns "Crop accepted", "Quantity fit", "Confirm before travel". Keep content and features consistent with another design direction so art direction alone changes.
Premium high-end credible digital product, readable functional form, intentional spacing, thin dividing rules, no generic card grid, no invented metrics, fake awards, gradients, badges, shopping cart, brand symbol, noisy illustrations, floating UI, browser chrome, or text outside website. No additional slogans or body copy beyond requested. All UI text English.
```

## C — Immersive landscape

File: [C-immersive-landscape.png](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/C-immersive-landscape.png)

Observation: strongest cinematic impression, but requires stronger navigation contrast and a lighter mobile crop. Use a static optimized image for the one-week build. No full 3D terrain engine is implied. Standardize all three previews' icons to one outline set in code.

```text
Use case: ui-mockup. Create one exceptionally polished, high-fidelity desktop website mockup for AniWhere, a Philippine farmer market-discovery product. Direction C: IMMERSIVE LANDSCAPE. One flat website screenshot, landscape 1536x1024 composition, no device frame, no perspective, no moodboard collage. A premium award-caliber geographic storytelling homepage that remains a usable product.
Wordmark text "AniWhere" only, no logo emblem. Exact UI palette: Olive #597928, Leaf #91AC67, Soil Brown #6E3511, Rice Cream #FCECD8, Warm Surface #FFFDF8, Ink #20251E, Route Blue #4E7380.
Large immersive hero occupying upper 70%: beautifully art-directed realistic aerial oblique view of Laguna-inspired lush tropical lowland farmland near the lake and hazy forested hills, winding rural roads, small farm parcels with varying green tones, quiet early morning atmospheric light. NOT mountains full of rice terraces, not alpine scenery. Landscape art provides cinematic depth, yet tidy interface remains sharp. Use deep Field Ink transparent scrim behind text for excellent readability. Subtle thin Route Blue route lines follow land with exactly three restrained cream location points; no complex dashboard overlays. One point has readable label "Sample cooperative"; small unobtrusive caption "Illustrative landscape".
Navigation across top: cream "AniWhere" at left; "Explore markets", "How it works", "For buyers", "EN / FIL"; cream outlined button "Find buyers".
Very large distinctive cream contemporary sans-serif heading left-center, exact: "More places for your harvest." Supporting exact: "Discover nearby buyers. Compare your options. Know who to call."
At the base of the landscape hero place a full-width warm-surface search console with clear labels and values: "Your crop" / "Tomato"; "Quantity" / "100 kg"; "Location" / "Laguna"; solid olive button "Find places to sell". Do not hide the form behind any entry button.
Below the hero a Rice Cream editorial band begins with "Can I sell here?" and three crisp compact columns "Crop accepted", "Quantity fit", "Confirm before travel". Spacious 12-column design grid, exceptional typography and alignment. Slight atmospheric landscape movement is only implied in the still.
No videos shown as players, no loading screen, no audio controls, no neon, glassmorphism, fake metrics, testimonials, awards, logo symbols, scrolling instruction, ornamental badges, giant floating cards, browser chrome, extra brands or additional slogans. All UI copy English.
```

