# AniWhere: current research, architecture and UI/UX handoff

Prepared 17 September 2026. This package plans the implementation and supplies three generated visual previews. It does not contain a finished application.

## Read in this order

1. [Architecture and build plan](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/AniWhere-architecture-and-build-plan-2026-09-17.md): product boundaries, stack, routes, data model, interfaces, fit rules, cost arithmetic, security, providers, data operations, seven-day work split and acceptance tests.
2. [UI/UX plan](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/AniWhere-uiux-plan-2026-09-17.md): the three directions, design tokens, measured contrast, typography, every core screen, mobile behavior, copy, empty/error states, motion and review criteria.
3. [Research and reuse sourcebook](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/AniWhere-research-sourcebook-2026-09-17.md): exact local repositories/commits/files, licenses, Awwwards references, competitors, data sources, discussions, official documentation and evidence limits.
4. [Generation prompts and image inspection notes](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/generation-prompts.md): reproducible prompts and limits of the generated artwork.

## Visual options

- [A — Editorial map](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/A-editorial-map.png)
- [B — Farm photography](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/B-farm-photography.png)
- [C — Immersive landscape](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/uiux-directions/C-immersive-landscape.png)

All three are concept images made with the built-in image-generation tool. The farmer in B is synthetic and the geographic imagery is illustrative. Rebuild the interface in semantic code; do not use a screenshot as the application. Final visual choice is pending. Recommendation: A as the product identity, optionally borrowing B's photographic approach in lower homepage sections. The logo is deliberately undecided.

## Decisions to preserve

- AniWhere stays a market-discovery application for farmers, similar to UPPETITE in its map/list interaction.
- Three builders, one-week implementation budget, software only.
- All Laguna is the directory scope. Tomato, eggplant and calamansi are the initial detailed-match commodities.
- Polished homepage plus a practical discovery app. Farmer browsing is accountless.
- English first with a visible Filipino switch.
- Use the exact seven supplied palette colors; apply the contrast rules in the UI/UX plan.
- Four explainable fit states; compare up to three options; show accepted and remaining quantities; contact before travel.
- Start with reviewed public sources. A place listing is not proof of current buying demand. Fictional demo buyers/offers live in an explicit separate scenario.
- No fabricated partners, prices, confirmations, income improvements, usage statistics or guarantees of an award.

## Corrections to older context

The public [Diannn3/aniwhere](https://github.com/Diannn3/aniwhere) repository exists and was empty when inspected. Older directions to create a new private repository are stale. Recheck it before scaffolding because Antigravity or another agent may have begun work.

The older `AniWhere-research-and-build-plan.md` and `AniWhere-concept-note-draft.md` contain AniPlan/pooling/optimization ideas. They are historical material. This package does not restore that direction. Preserve the completed Word concept note unless the user specifically requests a revision.

The local map sources are useful but not plug-and-play. UPPETITE contains restaurant filters, tight local bounds and hardcoded tile/attribution configuration. BetterSantaCruz's policy hardcodes one municipality. RoomTBA's isolated sheet and tests are the cleanest direct reuse target.

MapLibre's locally measured production modules already use approximately 275 KiB gzip before application code. The Day 1 renderer gate measures the actual app against the 300 KiB total-JS target; Leaflet is the predetermined fallback. No compliance result is claimed before that build.

## Immediate implementation sequence

Reinspect repository state and applicable instructions; settle the visual choice from the three previews; build one harvest-to-result-to-compare slice; measure the map bundle; implement evidence and matching rules; then add authenticated review, content, polish and the declared QA gates. The architecture plan specifies what to cut if time slips.

## What was completed in this pass

Read relevant local project context and named design guidance; inspected reusable code and repository licenses; researched primary product/data/design sources and developer/community discussions; generated and visually inspected three distinct UI concepts; calculated palette contrast and measured the installed map modules; wrote this linked planning package. Local links, image dimensions, comparison arithmetic and document consistency are checked as part of artifact review.

No application code, database schema, production deployment, external message or source-repository mutation was performed. Source retrieval failures and unverified leads are labeled in the sourcebook. Plans, demo fixtures and generated images must not be described as user validation or live market operations.
