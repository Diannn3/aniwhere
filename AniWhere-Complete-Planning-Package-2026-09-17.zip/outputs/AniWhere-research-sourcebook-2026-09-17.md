# AniWhere research and reuse sourcebook

Research date: 17 September 2026. Companion documents: `AniWhere-architecture-and-build-plan-2026-09-17.md` and `AniWhere-uiux-plan-2026-09-17.md` in this directory.

This sourcebook separates inspected evidence, design references, code candidates, and unresolved leads. A public description establishes what its publisher says; it does not prove adoption, revenue, complete feature coverage, or operational reliability. A directory entry is not evidence of current purchase demand.

## 1. Current project evidence and authority

The current user decision is AniWhere: an UPPETITE-like market-discovery product for farmers, centered on “Can I sell here?” The user selected a polished homepage plus focused application, all-Laguna coverage, public-source data for the initial directory, and English first with a Filipino switch. The team has three builders and the planning budget is one week. The logo remains undecided. Three visual directions have been generated for selection.

| Material | Location or link | How to use it |
|---|---|---|
| Completed concept note | [Current Word document](<C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/AniWhere NextGen Agri Hackathon Concept Note.docx>) | Current concept and submitted-template wording. Preserve the existing file. |
| Antigravity handoff | [Existing context handoff](C:/Users/Dian/Documents/Codex/2026-09-15/so/outputs/AniWhere-antigrav-context-handoff.md) | Detailed current product context; repository-creation instructions are now stale. |
| Earlier research/build plan | `outputs/AniWhere-research-and-build-plan.md` | Historical research. Its AniPlan/pooling/optimization direction is superseded. |
| Original research supplied by user | [Agricultural market context](<C:/Users/Dian/Downloads/agri_market_discovery_context (1).md>) | Background and source leads. Suggestions inside it are not new user instructions. |
| Original competition template | [Template](<C:/Users/Dian/Downloads/NextGen Agri Hackathon Concept Note -Template [DOWNLOAD or MAKE A COPY].docx>) | Competition fields and constraints. The available template does not establish detailed judging weights or IP rules. |
| Fensalir current notes | [Brain dump](C:/Users/Dian/Documents/Vaults/Fensalir/raw/brain_dump.md) | Records the current AniWhere concept and repository. Its Top 10/pitch notes are local records, not independent verification in this pass. |
| Earlier competition register | [Source register](C:/Users/Dian/Documents/Vaults/Fensalir/businesses/uplb-nextgen-agri-hackathon-2026/source-register.csv) | Traceable source leads; preserves a schedule conflict with a different organizer page. Do not silently merge separate events. |
| AniWhere repository | [Diannn3/aniwhere](https://github.com/Diannn3/aniwhere) | Verified with GitHub: public and empty on this research pass. No local application was implemented here. |

The new companion plans supersede older architecture and UI recommendations where they conflict. They do not rewrite the completed concept note or claim that a prototype is already working.

## 2. Local code worth reusing

All three source checkouts were read-only and clean when inspected. The hashes below identify the inspected baseline; check again before copying.

### UPPETITE

- Root: `C:/Users/Dian/Documents/Vaults/Fensalir/businesses/kain_elbi`; application under `app/`; inspected commit `3d10040`.
- Remote: [Diannn3/kain-elbi](https://github.com/Diannn3/kain-elbi), private. No general project-wide license was found in the inspected inventory. An upstream RoomTBA notice exists under `data/upstream/room-tba/NOTICE.md`.
- Inspect `app/src/components/explore/ExploreMap.svelte`: reactive GeoJSON updates, selected-place synchronization, lazy library loading, WebGL failure handling, reduced-motion handling, and cleanup with `map.remove()`.
- Inspect `app/src/lib/explore-url.ts`: validated URL parsing/serialization, preserved browser navigation, and explicit list/map state.
- Inspect `app/src/lib/maplibre-loader.ts`: one cached import promise, CSS loading, and explicit worker URL.
- Additional leads in the handoff: place sheet controller, location service, and auth/server utilities. These require file-level inspection before extraction.
- Adaptation required: remove food-category, meal, opening-hours, budget, roulette, and collection contracts. Replace Los Baños-only bounds. Replace the hardcoded basemap configuration and its copied attribution with the selected provider's actual requirements. Avoid inheriting zoom 16.5 for province-wide searches.
- Loader fix to include during adaptation: clear a rejected import promise so “Retry map” can make a real new attempt.
- Reuse posture: patterns and isolated user-owned utilities, with source records. Because AniWhere is public, do not publish an indiscriminate copy of the private repository. Prefer new domain components and the clearly licensed primitives below. Publication rights for any private third-party fragments remain a release check.

### RoomTBA

- Root: `C:/Users/Dian/Documents/Vaults/Fensalir/businesses/room-tba`; inspected commit `427774a1`.
- Remote and license: [Diannn3/room-tba](https://github.com/Diannn3/room-tba), [MIT license](https://github.com/Diannn3/room-tba/blob/main/LICENSE).
- Strong extraction targets: `src/components/svelte/BottomSheet.svelte`, `src/lib/bottom-sheet-snap.ts`, its unit tests, and `BottomSheet.component.test.ts` with its test host.
- The pure snap helper already distinguishes peek, expanded, dismiss, and no-change release intents. Preserve the tested gesture logic; add obvious buttons for the same actions.
- Do not import the complete navigation graph, room schema, campus datasets, 3D systems, database tooling, or map wrapper solely to obtain a sheet.
- Preserve original MIT notice and record the adapted files and commit in AniWhere's third-party notices.

### BetterSantaCruzLaguna

- Root: `C:/Users/Dian/Documents/Vaults/Fensalir/businesses/betterstacruzlaguna`; inspected commit `ea2f02f`; local LICENSE identifies CC0 1.0.
- Useful references: `src/lib/provenance.ts` and `src/lib/evidence/{policy,schemas,enums}.ts`.
- Reuse the separation of publication state, source review, assertion type, and freshness. Its policy refuses unverified/disputed claims and unresolved sources.
- Rewrite the civic terminology and geographic restrictions: the current policy contains the specific municipality PSGC `0403426000`. AniWhere covers Laguna and cannot retain that filter.
- Do not reuse its “fresh” default when no review cadence exists for a buying offer. Unknown demand validity must remain unknown. Place identity and purchase demand need different freshness rules.
- Do not import civic records as buyers. Evidence utilities and agricultural marketplace data have different purposes.

## 3. Open-source shortlist and decisions

License identifiers were checked against repository license endpoints/files in this pass. Pin actual versions and record copied-file provenance during implementation. Repository popularity is not the selection criterion.

| Repository | Inspected license | Decision and useful material |
|---|---|---|
| [Bits UI](https://github.com/huntabyte/bits-ui) | MIT | Selected: Svelte dialog, select, tabs, popover, focus primitives. Test the composed application behavior. |
| [shadcn-svelte](https://github.com/huntabyte/shadcn-svelte) | MIT | Selected reference: copy only needed form/dialog/button patterns and restyle them with AniWhere tokens. |
| [MapLibre GL JS](https://github.com/maplibre/maplibre-gl-js) | BSD-3-Clause, bundled notices | Preferred map renderer, subject to the early total-JS budget gate. Use point layers and clusters, no terrain dependency. |
| [Leaflet](https://github.com/Leaflet/Leaflet) | BSD-2-Clause | Predetermined fallback if MapLibre plus the application exceeds the required bundle budget. Use permitted raster tiles and the same map adapter. |
| [Turf](https://github.com/Turfjs/turf) | MIT | Import individual distance/bbox helpers only. Distance is straight-line until routing succeeds. |
| [Lucide](https://github.com/lucide-icons/lucide) | ISC plus MIT notices for Feather-derived icons | Selected Svelte icon set; preserve all applicable notices. Icons support text labels. |
| [Zod](https://github.com/colinhacks/zod) | MIT | Selected at server/data-import boundaries. Avoid shipping every validation schema to the browser. |
| [svelte-maplibre](https://github.com/dimfeld/svelte-maplibre) | MIT | Optional reference only. Direct MapLibre integration already exists locally; avoid adding a wrapper unless a concrete need justifies it. Check its supported MapLibre versions first. |
| [MiniSearch](https://github.com/lucaong/minisearch) | MIT | Deferred. A small crop-alias dictionary and normalized string filtering are sufficient for the first directory. |
| [idb](https://github.com/jakearchibald/idb) | ISC | Deferred until offline record snapshots are required. Small local harvest drafts and bookmarks can use versioned localStorage. |
| [openrouteservice](https://github.com/GIScience/openrouteservice) | GPL-3.0 server | Use its hosted directions API through a small server adapter. Do not copy or operate the full routing server in the one-week build. Hosted usage has separate quotas and terms. |
| [OSRM](https://github.com/Project-OSRM/osrm-backend) | BSD-2-Clause | Future self-hosted routing reference. Public demo endpoints are not AniWhere's production service. |
| [AgriMarket](https://github.com/NexLogik/agrimarket) | MIT | Basic agricultural marketplace reference. Its marketplace architecture is less aligned than UPPETITE's discovery flow; do not port a second framework. |
| [Open Food Network](https://github.com/openfoodfoundation/openfoodnetwork) | AGPL-3.0 | Domain/workflow reference for producers, enterprises and distribution. Full commerce stack and obligations are unnecessary for this MVP. |

Do not add React Bits, a React runtime, a chatbot framework, OR-Tools, a payment SDK, or a general CMS to the critical path. They do not serve the selected first-week workflow. The UI/UX Engineer's Svelte addendum explicitly points to shadcn-svelte and Bits UI for this stack.

### Local feasibility measurement

The installed UPPETITE MapLibre version is 6.2.0. Compressing its production modules individually gave approximately 137.4 KiB for the main module, 132.2 KiB shared, and 5.8 KiB worker: 275.4 KiB of JavaScript before AniWhere code. CSS was approximately 9.9 KiB gzip. This is a source-package measurement, not a production AniWhere bundle measurement. The architecture plan includes a Day 1 bundling check against the named guidance's 300 KiB target and a deterministic Leaflet fallback.

## 4. Website inspiration, with specific transfer decisions

Award labels below describe the linked Awwwards listing, not AniWhere. Nominee and Honorable Mention are not Site of the Day. Live sites can change after an award.

| Reference | Evidence/inspection | What to borrow for AniWhere |
|---|---|---|
| [Farm Minerals live](https://www.farmminerals.com/promo), [Awwwards case study](https://www.awwwards.com/farm-minerals-case-study.html), [award listing](https://www.awwwards.com/sites/farm-minerals) | Live desktop screenshot inspected; Awwwards search index confirms SOTD and Developer Award, February 19, 2026 | Confident scale, green/cream restraint, a single subject carrying the story. AniWhere's subject is finding a selling option. The source's loading sequence and product animation are not required. |
| [Explore Primland live](https://explore.ownprimland.com/), [Awwwards listing](https://www.awwwards.com/sites/explore-primland) | Live desktop introduction visually inspected; listing describes an interactive map and seasons toggle and records SOTD | Geography as a memorable brand element; clear place selection. Use a static landscape treatment if C is chosen, and a practical 2D map in the application. |
| [Beerenberg live](https://beerenberg.com.au/), [historical SOTD listing](https://www.awwwards.com/sites/beerenberg-farm) | Current page text inspected; award describes a Provenance Pathway product tracker. Historical award and current site are separate evidence | Human agricultural storytelling and visible provenance. AniWhere's equivalent is source/date/requirements, with actual rights to any people photography. |
| [Farm Africa](https://www.awwwards.com/sites/farm-africa), [menu reference](https://www.awwwards.com/inspiration/menu-design-farm-africa) | Awwwards indexed nominee; reference lead, no full interaction audit | Editorial narrative and restrained navigation. No donation/conversion claims are reused. |
| [Made for Spain & Portugal](https://www.awwwards.com/sites/made-for-spain-portugal-2), [interactive-map element](https://www.awwwards.com/inspiration/interactive-travel-map-made-for-spain-portugal-1) | Awwwards indexed Honorable Mention; component reference | Elegant map/list selection and regional labels without turning every result into a large card. |
| [Roadtrips South Australia](https://www.awwwards.com/sites/roadtrips-south-australia) | Awwwards indexed Honorable Mention, described as interactive mapping | Route context and regional exploration. Adapt the route presentation, not a travel itinerary planner. |
| [Zgoat](https://www.awwwards.com/sites/zgoat) | Awwwards indexed nominee for farm experiences/products; legacy reference | Evidence that farm discovery can support a considered editorial identity. The short horror-film website with a similar name is unrelated and was excluded. |
| [Airbnb search guidance](https://www.airbnb.com/help/article/252), [filters](https://www.airbnb.com/help/article/479) | Official functional reference; no Awwwards claim | Search context, coordinated maps/results, useful filters, and saved options. Replace booking language with harvest/requirements/contact. |

These are composition and interaction references, not permission to copy proprietary images, HTML, fonts, brand marks, or whole layouts. AniWhere's generated previews are original concepts. They are not production UI or evidence of an award.

## 5. Agricultural data sources and what they can support

| Source | Status in this pass | Permitted conclusion / product use |
|---|---|---|
| [DA CALABARZON investment guide, 2023](https://calabarzon.da.gov.ph/wp-content/uploads/2023/12/11282023-Investment-Guide-For-Selected-Agricultural-Commodities-in-CALABARZON-Booklet.pdf) | Official PDF indexed and rechecked | Historical commodity and institution leads. Recheck present address/contact/role before publication. |
| [DA CALABARZON KADIWA launch at PNP Camp Vicente Lim](https://calabarzon.da.gov.ph/kadiwa-ng-pangulo-sa-pnp-calabarzon-inilunsad-ng-da-4a-kasama-ang-13-fcas/) | Official page, posted July 1, 2025 | Records an event and participating organizations. It does not establish a permanent buyer, daily hours, or current purchasing volume. |
| [KADIWA supplier list](https://kadiwa.da.gov.ph/index.php/list-of-kadiwa-suppliers/) | Supplied lead; direct retrieval timed out | Supplier identity leads only until current page inspection succeeds. Suppliers may be sellers rather than buyers. |
| [DA price monitoring](https://www.da.gov.ph/price-monitoring/) | Official index retrieved; recent daily and weekly publications listed | Benchmark data with date, geography, unit and price stage. The weekly section is retail prices; do not relabel it as farmgate or a buyer offer. |
| [PSA farmgate metadata](https://openstat.psa.gov.ph/Metadata/Prices/Farmgate-Prices), [OpenSTAT API documentation](https://openstat.psa.gov.ph/API-Documentation) | Existing local register supplies these leads; no successful fresh table query claimed | Historical/regional context after extracting a traceable table. Never depend on a live PSA request during the demo. |
| [PSA Laguna crops, Q1 2026](https://rsso04a.psa.gov.ph/content/volume-production-other-crops-laguna-first-quarter-2026) | Carried from the local source register, not freshly verified in this pass | Potential pilot-commodity context. Revalidate before quoting a number in a pitch. |
| [DTI market-linkage initiative](https://supplychainlogistics.dti.gov.ph/strategic-play/market-linkage) | Carried source lead | Policy context for producer/institutional-buyer connections; not a live buyer directory. |
| [PSA PSGC](https://psa.gov.ph/classification/psgc) | Implementation source target; no download performed | Municipality identifiers and names. Pin the release used for the Laguna selector. |
| [OpenStreetMap copyright](https://www.openstreetmap.org/copyright) | Attribution reference | Geographic/place leads and map-data obligations. OSM categories cannot establish purchasing requirements. |

Initial content method: record a public source, classify the organization's role, verify the public business contact/address, preserve the publication date and separate review date, then publish only the supported fields. Where only an event is documented, publish an event with a validity period or leave it as a research lead. All-Laguna product coverage is not a claim that every municipality already has verified buyers.

## 6. Competition and differentiation

- [TABO](https://www.taboph.com/) currently describes profiles, a network feed, marketplace discovery, jobs, and planned e-commerce. This confirms substantial overlap with broad agricultural discovery. The page self-reports its competition award; AniWhere should not claim to be the first agriculture network.
- [Sakahon](https://www.sakahon.com/) describes coordinated sourcing, production planning, crop monitoring, consolidation, quality control and fulfillment. This reinforces the importance of grade, quantity and delivery conditions. It does not justify adding its entire operational model to AniWhere.
- [Ani Market](https://animarket.ph/) and [Farmia](https://farmia.ph/about/) are relevant prior-art leads from the supplied material. Retrieval failed in this pass. Their previously described feature sets are not presented here as freshly verified facts.
- The rest of the pasted comparison list remains a research lead list. Do not transform a previous LLM's “did not find” into proof of unique market coverage.

Defensible positioning: **AniWhere helps a farmer compare reachable selling options for a specific harvest, with reasons for fit, visible missing information, and transparent selling-cost calculations before making contact.** This is a focused product promise to demonstrate and validate, not an assertion that no competitor can do it.

## 7. Discussions and research that change implementation choices

| Source | Evidence type | Practical consequence |
|---|---|---|
| [Farm-to-table app discussion](https://www.reddit.com/r/BusinessPH/comments/1nt7ie1/farm_to_table_app_for_filipino_farmers/) | Public anecdotal discussion, indexed excerpts inspected | Local browsing and coop representation already recur in user ideas. Ask about operational constraints before adding checkout. Do not use thread price claims as market data. |
| [Why farmers use middlemen](https://www.reddit.com/r/BusinessPH/comments/1qz3h0z/why_do_farmers_usually_sell_through_middlemen/) | Public discussion, page retrieved | Comments raise pickup, cash flow, grading, consolidation and risk. Include these as requirements/contact questions. They are hypotheses to test locally, not representative survey results. |
| [SARE transportation project report](https://projects.sare.org/project-reports/onc20-070/) | Primary project report from Iowa/Minnesota | Delivery cost includes more than fuel. Trust and time constrain shared transport. Useful rationale for user-entered cost fields; not evidence of Philippine savings or a reason to restore pooling. |
| [MapLibre issue #4683](https://github.com/maplibre/maplibre-gl-js/issues/4683) | Maintainer discussion of cooperative gestures with rotation disabled, reported against 4.7.0 | Test Ctrl/trackpad zoom followed by drag. Do not assume the older report proves a defect in the pinned 6.x build. |
| [Bits UI issue #2135](https://github.com/huntabyte/bits-ui/issues/2135) | Open focus-scope report, read with reproduction description | Test initial sheet/dialog focus and focus restoration. A library's accessibility intent does not verify the composed UI. |
| [openrouteservice API-plan discussion](https://ask.openrouteservice.org/t/pricing-plan-from-the-api/5806) | Official provider forum, older discussion | Hosted API limits differ from running your own server. Resolve current limits at setup; calculate routes on request and cache permitted responses. |

## 8. Standards, documentation and provider constraints

- [UI/UX Engineer](C:/Users/Dian/Documents/Vaults/Fensalir/systems/agents/13_ui_ux_engineer.md): named local guidance used directly; Svelte addendum, six viewport checks, reduced motion, deliberate typography and interaction budgets.
- [UI/UX Pro Max](C:/Users/Dian/.agents/skills/ui-ux-pro-max/SKILL.md): searched for the product design system and UX/Svelte recommendations. Retained accessibility/touch/typography rules. Rejected the generic replacement palette and horizontal-scroll recommendation because they conflict with this brief.
- [Web Interface Guidelines](https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md): read current rules for labels, semantics, focus, stateful URLs, loading, safe areas, errors and motion. Apply framework-equivalent behavior, not React-specific syntax, in Svelte.
- [Astro Svelte integration](https://docs.astro.build/en/guides/integrations-guide/svelte/): native island composition reference.
- [Supabase PostGIS](https://supabase.com/docs/guides/database/extensions/postgis): geographic points, GiST indexing and nearest-neighbor queries.
- [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security): restrict rows by publication and authenticated membership. Grants and row policies are separate concerns.
- [MapTiler authentication](https://docs.maptiler.com/cloud/api/authentication-key/), [pricing](https://www.maptiler.com/cloud/pricing/): use a domain-restricted public map key and required attribution. Current Free description is testing/personal/non-commercial use; do not assume it covers a commercial launch.
- [openrouteservice services](https://openrouteservice.org/services/), [API](https://api.openrouteservice.org/), [restrictions](https://openrouteservice.org/restrictions/): route estimates are optional enrichment, not guaranteed truck accessibility or haulage quotations.
- [OSM tile policy](https://operations.osmfoundation.org/policies/tiles/): community tiles are capacity-limited, require attribution, and prohibit bulk/offline prefetch. Use a chosen permitted provider; no offline tile packs in v1.
- [Nominatim policy](https://operations.osmfoundation.org/policies/nominatim/): public endpoint is unsuitable for client autocomplete and limits total app traffic. The proposed municipality selector searches bundled data and makes no public Nominatim calls.
- [W3C contrast](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [target size](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html): AA normal-text contrast is 4.5:1. AniWhere chooses 44–48px controls for usability; 44px is a product target, not a claim about the WCAG 2.2 AA minimum.
- [Web Vitals](https://web.dev/articles/vitals): use LCP, INP and CLS targets, distinguish controlled lab results from real-user measurements.

## 9. What is still unverified

No farmer interview, live buyer onboarding, location visit, market-price extraction, demand confirmation, adoption metric, income improvement, prototype build, RLS migration, or production deployment was completed in this research/design pass. Website inspections are reference studies, not full accessibility audits. The three generated images are visual concepts. The architecture and UI/UX documents define future implementation and acceptance checks.
