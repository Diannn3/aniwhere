# AniWhere research and seven day build plan

Research checked 15 September 2026. Prepared for a team of three builders considering the NextGen Agri Hackathon 2026. This is a product recommendation and research handoff, not a completed application or a claim of validated farmer impact.

## Recommendation

Build AniWhere around **AniPlan: a selling plan for the whole harvest, with a fallback when a buyer drops out**.

A farmer enters crop, quantity, location, availability, and buyer-relevant grade. AniPlan compares feasible selling plans, can split a harvest across two buyers, and shows estimated sale proceeds after selling costs. A bounded pooling option helps meet one buyer's minimum quantity, but only if each participant is at least as well off under the model as their documented individual alternative. If an offer expires or a buyer withdraws, AniPlan recalculates the uncommitted remainder and explains what changed.

The memorable demonstration is a buyer cancellation followed by a transparent, recalculated Plan B. This is more distinctive than displaying a map, adding a chatbot, or claiming that transport-aware price comparison is new.

**Defensible novelty statement:** AniWhere proposes a Philippine farmer-facing workflow combining whole-harvest allocation, buyer constraints, transparent cost comparisons, optional pooling, and cancellation replanning. The reviewed public pages did not establish this exact workflow as a core feature of the named Philippine competitors. That is a bounded research observation, not proof that no competitor offers it or that the underlying algorithms are novel.

Winning cannot be guaranteed. The practical route to a strong entry is a narrow working decision engine, credible data boundaries, one well-rehearsed disruption scenario, and feedback from actual farmers and buyers.

## What the supplied template establishes

The supplied NextGen Agri Hackathon concept note describes a student innovation challenge for Philippine agri-food problems. It asks for team and institutional details, a project title, focus sectors, a problem statement of at most 200 words, target users, solution and novelty, prototype strategy, and business model. It allows three to five members. Your three-builder team fits that size.

It does **not** provide judging weights, coding-period rules, AI requirements, submission time, presentation length, or evidence that a production deployment is required. Do not invent those requirements. For this concept, choose Digital Agriculture and Value Chain Development; Agri-Enterprise Development is also defensible if the cooperative workflow is included.

A third-party repost of a UPLB TTBDO announcement states a 15 September 2026 concept-note deadline and 25 September pitch day. The official registration and submission pages could not be opened during this research, so treat those dates as **unconfirmed scheduling leads** and check your organizer communications immediately. [Reposted announcement](https://www.schoolandcollegelistings.com/PH/Los-Ba%C3%B1os/316594745103789/UPLB-Technology-Transfer-and-Business-Development-Office)

The attached dossier and pasted LLM answer were treated as background claims to investigate. Your decision to use AniWhere overrides the older dossier's statement that no name was selected.

## Competitor findings that change the concept

These are public product descriptions or program announcements, not hands-on verification of every feature or proof of adoption. An unmentioned feature is unknown, not absent.

| Project | What the reviewed evidence supports | Consequence for AniWhere |
|---|---|---|
| [TABO](https://www.taboph.com/) | Profiles, connections, feed, marketplace discovery, jobs; ecommerce and AI features described as upcoming. Its own [competition account](https://www.taboph.com/news/from-an-idea-to-grand-champions-our-solutionsfest-journey) reports a SolutionsFest 2026 grand championship. | Agriculture discovery alone is not a strong novelty claim. Award status here is self-reported, not independently verified. |
| [Ani Market](https://animarket.ph/) | Pre-harvest farmer-to-business matching and logistics coordination; site explicitly says app in development. | Finding buyers before harvest is already a stated proposition. Do not equate a landing page with a mature operating app. |
| [Farmia](https://farmia.ph/about/) | Seller listings, prices, stock, orders, fulfillment, and visibility into estimated seller payout; harvest-on-order for eligible products. | Even a payout estimate is insufficient as a headline differentiator. |
| [Sakahon](https://www.sakahon.com/) | Business requirements, planned production, quality control, consolidation from multiple farms, packaging and fulfillment. | Aggregating farmers for business buyers already has close Philippine prior art. |
| [DA Region 10, OIC and GGMC](https://cagayandeoro.da.gov.ph/index.php/agri-10-oic-ggmc-ink-moa-to-boost-farmers-market-access-through-digital-platform/) | Announced matching platform, pooled harvest volumes, aggregation hubs, logistics and institutional buyers. | Map plus demand plus pooling is not enough to claim a unique Philippine category. |
| [Yakamoo](https://www.plantnationph.com/articles/introducing-yakamoo-platform-filipino-farmers) | Marketplace, logistics, farm dashboard, learning and community tools are advertised. | A feature-heavy farmer super-app is already a crowded proposition. |
| [Mayani via World Bank coverage](https://www.worldbank.org/en/news/feature/2025/11/21/supporting-rural-transformation-in-the-philippines) | Connects farmer associations to institutional buyers. | Add this significant comparator to the original list. |
| [KADIWA locator](https://pia.gov.ph/news/kadiwa-sites-nearby-now-searchable-on-egovph-app/) | eGovPH location discovery for KADIWA centers. | A nearby selling-location map by itself will be easy to compare to existing services. |
| [Digital Green Loop](https://digitalgreen.org/wp-content/uploads/2023/12/Digital-Green-Loop-brief-June2017.pdf) | Historical program combined human aggregators, perishables pooling, transport savings, market access and digital receipts. | Pooling, transport savings and receipts are established approaches. Current operation was not established in this review. |
| [Buzzar](https://buzzarr.com/) | Commodity, quantity and location input; market comparison using transport, distance and estimated net realization. Its page separates future trade execution from its current claims. | Particularly close to the original decision-engine pitch. Geographic adaptation alone does not make that idea new. |
| [Mandi Mitra](https://play.google.com/store/apps/details?id=com.mandimitra.mandimitra) | Store listing advertises market rates and a quantity/transport-based profit calculator. | A transport calculator is a useful component, not a unique invention. |
| [Open Food Network](https://github.com/openfoodfoundation/openfoodnetwork) | Open-source food marketplace connecting farms, hubs, cooperatives and customers. | Study existing food-network workflows instead of reinventing marketplace plumbing. |

The remaining names in the supplied material, including NVAT Fresh, Deliver-E, MooMart and international farm locators, remain useful background leads. This research prioritized the stronger comparisons above; it does not claim to have performed a full operational teardown of every name in the screenshot.

### What is genuinely different in the proposed demo

The farmer gets an allocation rather than a list of prices: which quantity goes to which buyer, what remains unallocated, what conditions must hold, and what the alternative becomes after a cancellation. A cooperative sees each participant's outcome rather than only the group's total gain.

The value is the **decision and its explanation**. An algorithm that sends everyone to the same high-price buyer, ignores capacity, or hides one farmer's loss would fail this product's core promise.

## Feature selection

These are design judgments for three builders and seven days, not measured scores or a known judging rubric.

| Candidate | Differentiation potential | One-week suitability | Decision |
|---|---|---|---|
| Map and buyer directory | Low on its own | High | Supporting discovery surface |
| Price minus transport | Low on its own | High | Required economic calculation |
| Whole-harvest split plus cancellation replan | Strong demo distinction against reviewed local pages | Good when restricted to two destinations | Main feature |
| One pool with per-farmer benefit checks | Useful supporting distinction, established research basis | Moderate with fixed hub and small group | Include only within hard limits |
| Voice input | Helpful access feature, common prior art | Variable across languages and devices | Optional text input first |
| Crop-price forecasting | Crowded and hard to validate locally | Poor | Defer |
| AI produce grading or shelf-life predictions | Requires representative evidence and validation | Poor | Defer |
| Automated negotiation, bidding, payments and escrow | Adds operational and trust obligations | Poor | Defer |
| Nationwide routing and multi-truck dispatch | Large optimization and data problem | Poor | Defer |

## Proposed experience

### 1 Enter the harvest

Start with a short form: crop, kilograms, town or map pin, ready date. Offer a plain-language grade/condition choice based on the pilot buyer specifications. Ask about pickup availability and payment deadline only when needed to distinguish options. A cooperative operator can enter information on behalf of a farmer with consent.

For the demo, crop selection can be limited to tomatoes. Use two buyer-defined grade categories. Do not claim these are universal grading standards or infer food safety from a photo.

### 2 Show feasible options

Each buyer card includes accepted crop/grade, available demand, minimum lot, price basis, offer expiry, receiving window, pickup/delivery terms, payment timing and data source. Show explicit states such as directory lead, buyer-posted offer, reconfirmation required and closed.

A restaurant appearing on a map is not evidence that it buys raw tomatoes from outside farmers. A KADIWA store may be a retail venue or supplier program rather than an open buyer. Explain the next action appropriate to that record: contact to check, apply as supplier, or request confirmation of an actual offer.

### 3 Generate AniPlan

Display one recommended feasible plan plus alternatives:

- Estimated proceeds from the complete plan.
- Kilograms allocated and unallocated.
- Transport and other selling costs.
- Payment expected today versus later.
- Conditions still needing confirmation.
- Comparison with the usual outlet and the best modeled solo option.

The map supports the plan. Keep a complete list and receipt view usable when the map does not load.

### 4 Optional pooling

Limit the first build to one same-crop pooling offer, one coordinator, one fixed hub, and at most three farmers. Neighbors declare available quantities and opt in. Calculate their actual contribution, transport share, and comparison outcome. Do not allocate an entire combined harvest to a buyer whose capacity is smaller.

The prototype proposes a pool. A buyer, coordinator, and participants still need to confirm it. The app does not create a truck, guarantee acceptance, or establish a partnership by displaying it.

### 5 Replan the unsold portion

Withdraw the processor offer in a second demo view. Recalculate only produce that can still be reassigned. Delivered or committed quantities remain locked; cancellation releases the affected reservation only through the appropriate state transition. Expired prices trigger reconfirmation rather than silently remaining available.

The strongest honest fallback is sometimes: “No confirmed replacement for 180 kg yet. Here are two leads to contact.” Do not make the UI invent a successful sale when none is feasible.

### 6 Explain the decision

A compact decision receipt shows quantities, buyer prices, every deduction, timestamps, assumptions, status and the next confirmation action. It is a plan summary, not an invoice, payment receipt or guaranteed contract. Let the farmer download or copy it as text.

## A complete demo scenario

**All entities, prices, grades, capacities, costs and timing below are fictional test fixtures. They are not observed market rates, partnerships or impact results.** All offers use the same modeled selling day and same-day payment. Receipt amounts exclude growing costs and assume accepted quantities are paid in full.

Farmer Ana has 300 kg of tomatoes: 120 kg accepted by a fresh-market buyer and 180 kg of sound processing-grade tomatoes. Two neighbors have 140 kg and 180 kg of processing-grade tomatoes. Processing-grade does not mean spoiled or unsafe.

| Offer | Capacity and condition | Price and selling costs |
|---|---|---|
| Usual outlet | Accepts both pilot grades; enough modeled capacity | ₱18/kg; Ana pays ₱300 per trip; each neighbor's individual trip costs ₱2/kg |
| Fresh-market buyer | Up to 120 kg, accepts only Ana's fresh-market grade | ₱28/kg; buyer pickup, no seller charge in fixture |
| Distant bulk buyer | Minimum 300 kg from one farm; accepts both pilot grades but no pooled lots in this fixture | ₱30/kg; ₱2,800 trip cost; either neighbor alone is below minimum |
| Processor pool | Exactly 500 kg of processing grade for this fixture | ₱23/kg; shared trip ₱1,000, allocated by contributed kilograms |

The neighbors' available grades make them ineligible for the fresh-market offer; their volumes make them individually ineligible for the distant offer. The distant buyer's single-farm condition prevents a different pooled allocation from changing this particular example. This is a deliberately bounded demonstration, not evidence that processors always provide the best pooled option. The same capacities and compatibility rules must apply to every comparison.

| Ana's plan | Calculation | Estimated sale proceeds |
|---|---|---:|
| Usual outlet | 300 × ₱18 − ₱300 | ₱5,100 |
| Highest headline price | 300 × ₱30 − ₱2,800 | ₱6,200 |
| Best modeled solo split | 120 × ₱28 + 180 × ₱18 − ₱300 | ₱6,300 |
| AniPlan with pool | 120 × ₱28 + 180 × ₱23 − ₱360 | ₱7,140 |

The processor's 500 kg is exactly 180 + 140 + 180. Ana pays 180/500 of the ₱1,000 trip. The neighbors receive ₱2,940 and ₱3,780 after their transport shares, versus modeled individual alternatives of ₱2,240 and ₱2,880. All three benefit under these assumptions.

Ana's improvement is **₱2,040 against her usual outlet**, but only **₱840 against the best modeled solo plan**. Show both. The latter is the more informative comparison for the extra value of pooling. Those are 40% and approximately 13.3%, respectively, in this invented fixture only.

If the processor cancels **before dispatch or paid transport is incurred**, the remaining 180 kg can return to the usual outlet, assuming its capacity and terms remain available. Ana's plan becomes ₱6,300. Show the changed amount and the pending replacement confirmation. Cancellation after departure requires sunk costs and timing to be included and should be outside the first demo.

If the pool's trip cost varies from ₱800 to ₱1,400, Ana's modeled proceeds range from ₱7,212 to ₱6,996. This is a user-specified cost scenario range, not a statistical confidence interval.

The arithmetic above was checked with Python. A production optimizer, route accuracy, reservations, UI and real-world outcomes were not built or validated in this research task.

## Economic and algorithm rules

### Use the correct money label

Use **estimated sale proceeds after selling costs**. Revenue minus transportation and market fees is not full farm profit: seed, fertilizer, land, labor and other production costs are absent. If you later add growing costs, disclose which costs are included and whether you are estimating margin or full profit.

For farmer i under plan a:

`proceeds(i,a) = sum(accepted_kg × quoted_price_per_kg) − transport_share − handling − packaging − market_fees − other_applicable_selling_costs`

If rejected quantity is already removed from accepted kilograms, do not subtract its missing revenue a second time as a spoilage charge. Add actual disposal or extra handling separately if applicable. Unknown costs must be shown as missing or an explicit scenario, not silently assumed zero outside test fixtures.

### Feasibility comes before ranking

Reject incompatible plans before comparing money:

1. Correct commodity, variety where relevant, and buyer-defined grade.
2. Allocated kilograms cannot exceed available, unreserved supply.
3. Total assignments cannot exceed the buyer's remaining capacity.
4. Buyer minimum lots and all-or-nothing conditions hold.
5. Harvest, pickup, travel, receiving window and farmer-declared sell-by deadline are compatible.
6. Transport capacity and user spending limit hold.
7. Payment date meets any farmer cash deadline; future receivables are not labeled cash today.
8. Offers are current enough to use, and tentative plans remain visibly tentative.

Do not combine pesos, distance, demand fit and an invented reliability score into an arbitrary weighted sum. Route costs already reflect part of distance. Explain actual tradeoffs and let the user set hard preferences such as same-day payment or maximum out-of-pocket transport.

### Keep the solver small

For one week, consider at most six buyer offers, two sale destinations for the focal farmer, one fixed pooling option, and one fixed aggregation hub. Neighbor quantities are explicitly supplied to that pool; do not attempt unrestricted coalition search across every farm.

Either implement a small deterministic candidate enumerator using a documented kilogram/crate increment, or use OR-Tools CP-SAT if a team member is already comfortable with Python. CP-SAT uses integer constraints; represent money in centavos and quantities in a documented integer unit. Return solver status and do not call a time-limited feasible answer a proven optimum. [Official CP-SAT documentation](https://developers.google.com/optimization/cp/cp_solver)

A 10 kg increment reduces search space but can miss better allocations between increments; disclose that restriction or support 1 kg units for the small fixture. A bounded enumerator is not an unrestricted national optimizer.

For each generated candidate, calculate the trip cost once for a shared trip, apply the agreed cost-sharing rule, then assess every participant. Two nominally independent destinations can require a combined route; either price the actual modeled route or clearly assume separately quoted trips. A fixed hub makes that tractable.

### Pooling benefit rule

For every participant require `pooled_proceeds >= documented_solo_proceeds`, with consistent quantity, grade, time, and costs. Show which solo alternative is used. A weak baseline must not be disguised as the best possible alternative. If the test fails, reject the proposal or request a revised allocation; do not hide the losing participant in a larger group total.

A kilogram-based transport share is understandable for one shared hub-to-buyer leg. Add individual farm-to-hub costs separately. Weight alone is not universally fair when pickup distances, handling or grades differ. More sophisticated sharing is future research: a SARE project already implemented route and Shapley-value cost sharing in a spreadsheet, so cost-sharing mathematics itself is not AniWhere's invention. [SARE project report](https://projects.sare.org/project-reports/onc20-070/)

### Status and data integrity

Separate record evidence from transaction state. Evidence might be historical directory, buyer-posted, manually reconfirmed, or demo. Transaction state might be proposed, requested, confirmed, cancelled, expired, dispatched or completed. A real location plus a demo price still produces a demo scenario.

Use offer versions and expiration times. A saved proposal does not reserve capacity. A confirmation must atomically check and reduce available capacity to prevent two farmers booking the same remaining demand. Store which inputs produced a plan so changed offers can invalidate it.

## Useful Philippine data and its limits

| Resource | Use this week | Boundary |
|---|---|---|
| [DA CALABARZON investment guide](https://calabarzon.da.gov.ph/wp-content/uploads/2023/12/11282023-Investment-Guide-For-Selected-Agricultural-Commodities-in-CALABARZON-Booklet.pdf) | Historical vegetable buyer/processor and trading-area leads. Indexed page 14 includes LATC in Calauan and Tanauan City Trading Post. | Buyer tables are labeled 2021. The full large PDF could not be fetched by the web reader; relevant tables were available in its indexed extract. Reconfirm operation, location, crops and contacts. |
| [KADIWA supplier directory](https://kadiwa.da.gov.ph/index.php/list-of-kadiwa-suppliers/) | Identify cooperative or supplier organizations and listed commodities. | These are suppliers, not automatically buyers or confirmed aggregation partners. Avoid copying personal contact details unnecessarily. |
| [DA Price Monitoring](https://www.da.gov.ph/price-monitoring/) | Dated contextual price references; page includes 2026 weekly retail reports. | Retail prices are not buyer offers or farmgate prices. PDFs need table/date/unit checks. |
| [PSA OpenSTAT farmgate metadata](https://openstat.psa.gov.ph/Metadata/Prices/Farmgate-Prices) | Historical province/commodity price context. Fruit vegetable new-series table ID is 2M4AFN05. | Metadata verified; an end-to-end extraction and latest tomato values were not verified. Check old versus new series and observation periods. |
| [Bantay Presyo](https://www.bantaypresyo.da.gov.ph/) | Supplemental market price reference and trading-post research. | A page advertising daily updates does not verify freshness of every row or expose a confirmed buyer-demand API. |
| [DTI market-linkage program](https://supplychainlogistics.dti.gov.ph/strategic-play/market-linkage) | Understand how institutional buyers, food terminals and trading posts are linked. | Program resource and possible introduction route, not a live offer feed. |
| [OpenStreetMap data](https://www.openstreetmap.org/copyright) | Locations and road-network basis. | Market existence does not prove current buying demand. Verify exact destination access and preserve attribution. |
| Buyer or cooperative form | Actual pilot demand, grade, quantity, expiry and receiving windows. | Strongest operational data comes from willing participants, with timestamps and confirmation. No such interviews or onboarding were performed in this task. |

No public, nationwide live feed of buyer-specific willingness to buy, quantity, grade, payment terms and expiry was verified. Do not promise one. The MVP can use a small manually curated directory, a buyer-entry form, and explicitly labeled synthetic offers for the demonstration.

**Suggested pilot:** a Laguna-based tomato scenario with a small Calauan–Los Baños–San Pablo discovery area, if your team can access participants there. This is a convenience and interview-access recommendation, not a finding that this corridor has the best tomato volumes or confirmed processor demand. Choose an accessible real cooperative over a theoretically ideal region.

## Repositories and technical resources

Repository existence and metadata were checked using GitHub CLI. README content was inspected for Open Food Network and VROOM; other entries had metadata, license or example-list checks as specified below. No repository was installed or run, so these are evaluated starting points, not tested integrations. Pin actual dependency versions when building.

| Repository | Use | License and inspection notes |
|---|---|---|
| [google/or-tools](https://github.com/google/or-tools) | Allocation with capacity/minimum constraints; start with [assignment example](https://github.com/google/or-tools/blob/stable/examples/python/assignment_with_constraints_sat.py). | Apache-2.0; active September 2026; example filename verified through contents listing. |
| [Leaflet/Leaflet](https://github.com/Leaflet/Leaflet) | Simple mobile-friendly map, markers and route lines. | BSD-2-Clause; metadata checked, active September 2026. Recommended if it is already familiar to the team. |
| [maplibre/maplibre-gl-js](https://github.com/maplibre/maplibre-gl-js) | Alternative for vector-map styling. | License file has BSD-style terms and bundled notices; GitHub classifies it as Other. Inspect all required notices rather than relying on the short classifier. |
| [Project-OSRM/osrm-backend](https://github.com/Project-OSRM/osrm-backend) | Road route and distance/duration matrix. | BSD-2-Clause; active September 2026. [Official API documentation](https://project-osrm.org/docs/v5.24.0/api/) describes route and table services. Route time is not live traffic or a trucking quote. |
| [VROOM-Project/vroom](https://github.com/VROOM-Project/vroom) | Later multi-vehicle pickup, delivery, capacity and time-window routing. | BSD-2-Clause; README inspected. Works with routing engines/custom matrices; a separate concern from farmer revenue allocation. Defer for this MVP. |
| [openfoodfoundation/openfoodnetwork](https://github.com/openfoodfoundation/openfoodnetwork) | Domain patterns for farms, hubs, local food stores and orders. | AGPL-3.0; README inspected, active September 2026. Study workflows; adopting the entire application is more work than this build needs. Review obligations before incorporating its code. |
| [jakearchibald/idb](https://github.com/jakearchibald/idb) | Save draft harvests and last-viewed plan data locally. | ISC; metadata checked, last push reported May 2025. Local storage alone does not implement multi-user offline synchronization. |
| [digitalgreenorg/loop](https://github.com/digitalgreenorg/loop) | Historical implementation lead. | Last push reported May 2018, no license detected, README endpoint returned 404. Do not assume it is an immediately reusable starter. |

Searches also surfaced numerous student farm-marketplace repositories, but many advertised generic listing/payment/AI workflows with little evidence of operational validation. They are less valuable than established routing, optimization and local-food-network projects for AniWhere's distinguishing work.

### Recommended stack

- React and TypeScript with the team's familiar build tooling.
- Leaflet for the initial map, unless the team already works faster in MapLibre.
- One FastAPI service for offers, plan generation and state changes.
- SQLite for a single-server hackathon prototype; use PostgreSQL if already available and understood.
- A small deterministic planner or OR-Tools, with one shared typed/schema-validated data contract.
- Plain text export plus a locally saved last-known plan. Keep stale data visible.
- A routing provider or small authorized cached route fixture set; manual transport quote overrides.

Do not add a new database platform, extra optimization server, messaging provider, payment stack and AI agent framework simultaneously. The winning technical work is the plan behavior and data consistency.

For a demo without reliable connectivity, preload your own offer fixtures and permitted route data. Do not bulk-download OSM's public raster tiles; use a provider permitting offline tiles or allow the map to disappear while the plan still works. Public Nominatim forbids client-side autocomplete and sets a maximum of one request per second; a small locality selector and manual pin are simpler. [OSM tile policy](https://operations.osmfoundation.org/policies/tiles/), [Nominatim policy](https://operations.osmfoundation.org/policies/nominatim/)

### Minimal records

`HarvestLot`: owner, commodity, buyer-relevant grade, available kilograms, coarse location, ready time, declared sell-by time, reserved kilograms.

`BuyerOffer`: buyer, commodity/grade rules, minimum/maximum kilograms, remaining capacity, price/unit, expiry, receiving window, pickup terms, payment time, evidence state, version.

`TransportQuote`: route or hub leg, vehicle/capacity, amount or range, included costs, payer, quote timestamp, source.

`Plan`: immutable input versions, assignments, leftovers, cost breakdown, baseline comparison, assumptions, solver status.

`Pool`: coordinator, proposed member contributions, member decisions, hub, buyer offer, per-member transport shares and benefit checks.

`Reservation`: offer, lot, kilograms, state and version. Keep contact/precise-location access separate from public map information.

## Seven day execution plan for three builders

| Day | Builder 1 — product and frontend | Builder 2 — planner and data | Builder 3 — backend and integration | Completion evidence |
|---|---|---|---|---|
| 1 | Harvest flow and receipt sketch; farmer interview | Normalize fixture and economics; buyer interview | Offer schema and API contract; cooperative/logistics interview | Agreed scenario and definitions; honest notes, not invented personas |
| 2 | Form, buyer cards and list/map | Feasibility filters, single-buyer and two-buyer allocation | Offer CRUD, timestamps and persistence | Same inputs yield the same explainable plan |
| 3 | Compare usual, best solo and proposed plans | Cost allocation, leftovers, edge cases | Offer expiry, capacity handling and confirmation states | End-to-end solo split works |
| 4 | Small pool panel and contribution receipt | One fixed-hub pool with benefit checks | Buyer/coordinator demo views and state changes | No oversold kilograms or hidden losing participant |
| 5 | Replan transition and empty-state explanation | Cancellation replan, lock committed quantities | Invalidation and stale-data handling; route integration | Buyer withdrawal changes the remaining plan correctly |
| 6 | Farmer/coordinator usability feedback and language refinements | Independent calculation checks and scenario comparisons | Mobile, network failure and concurrent confirmation checks | Recorded failures corrected; tested scope documented |
| 7 | Pitch and rehearsal | Freeze fixtures and results | Stabilize deployment/demo fallback and record backup video | Reproducible demo and evidence-backed claims |

Daily integration matters more than three isolated feature branches merging on the last day. All builders should observe at least one domain conversation if possible.

**Cut order if behind:** voice input, fancy map animation, extensive directory, live external routing, then automated pool formation. Preserve harvest entry, truthful offers, complete-plan economics, cancellation replanning and explanation. If pooling cannot be tested, describe it as the next increment rather than pretending it works.

### Meaningful validation cases

- Highest price loses after trip cost.
- Small high-price buyer accepts only part of a harvest; remainder is visible.
- Grade incompatibility prevents an apparently profitable match.
- Two plans cannot confirm the same buyer capacity concurrently.
- A 530 kg group cannot allocate 530 kg against a 500 kg cap.
- Pooling that improves total proceeds but hurts a participant is rejected.
- Zero offers, expired offers, disconnected roads and missing transport costs produce explicit states.
- Withdrawal before dispatch recalculates only affected/uncommitted quantities.
- Deferred payment fails a cash-today requirement.
- Route/API failure leaves a usable list and explicitly stale or estimated route information.
- A keyboard and mobile user can complete the core flow; marker meaning does not rely only on color.

## Research and discussions worth reading

### Philippine market-choice research

[Rivas and colleagues, Identifying Optimal Market Choices for Coffee Farmers in Sultan Kudarat, 2025 preprint](https://arxiv.org/abs/2505.06323). Models allocation across market outlets and product forms under cost assumptions. Useful evidence that optimization can be framed locally. It uses coffee and annual-average assumptions; its results do not validate tomato prices, short-horizon demand or AniWhere's impact. The abstract was reviewed, not all 25 pages.

### Lessons from aggregation programs

[Digital Green account of its Bangladesh market-access work](https://digitalgreen.org/tech-solutions-for-smallholder-farmers-in-bangladeshs-jessore-district/) describes trusted aggregators, transport coordination, separate farmer lots, and SMS records. Product lesson: preserve provenance and a human coordinator rather than mixing everyone's produce and assuming software creates trust. Historical program results are not AniWhere metrics.

[The challenges of aligning aggregation schemes with equitable fruit and vegetable delivery, 2021](https://www.sciencedirect.com/org/science/article/pii/S2044083921000091) examines tradeoffs in the Loop network. Product lesson: gains to participating producers do not automatically establish better access for every downstream market. This research does not prove the proposed Philippine intervention will work.

### Transparent cost sharing

[SARE Full Trucks for Higher Profits](https://projects.sare.org/project-reports/onc20-070/) is especially practical: farmer and food-hub interviews, trust concerns, transport cost estimation, routing and a spreadsheet cost-sharing tool. Read it before claiming that pooling is just adding neighboring kilograms. It provides design precedent, not Philippine parameter estimates.

[Collaborative logistics for agricultural products, 2024](https://www.sciencedirect.com/science/article/pii/S0957417424013885) studies collaborative routes and Shapley-based sharing. The accessible publisher text was reviewed; do not implement its entire research pipeline within a week.

### Community criticism

[Farm to Table App for Filipino Farmers, r/BusinessPH](https://www.reddit.com/r/BusinessPH/comments/1nt7ie1/farm_to_table_app_for_filipino_farmers/) includes objections about fulfillment, quality, disputes, existing trading relationships, technology access and proposals that assume effortless coordination. These are anonymous anecdotes and interview prompts, not a representative farmer survey. Design implication: test the current selling process before asking users to replace it.

[Vegetable-market app discussion, r/PhStartups](https://www.reddit.com/r/PhStartups/comments/1sngzog/i_built_an_app_that_aims_to_revolutionize/) is another discovery lead showing developers exploring price visibility in the same space. The retrieved post promotes a price tracker; creator claims and comments were not independently validated.

[Open Food Network community](https://community.openfoodnetwork.org/) is linked from the verified project README and is a useful next discussion venue for food-hub workflows. Specific threads were not inspected in this pass.

### Broader context

[World Bank, Supporting Rural Transformation in the Philippines](https://www.worldbank.org/en/news/feature/2025/11/21/supporting-rural-transformation-in-the-philippines) connects digital marketplace work with farmer associations and physical logistics. Use it to explain why AniWhere should complement existing institutions. Do not attribute the results of larger infrastructure and enterprise programs to a standalone app.

## Minimum domain validation

Aim for three farmer conversations, two buyer conversations and one coordinator or transporter conversation. These are recruitment targets, not interviews already completed. Even a small convenience sample should retain dates, role, location, consent, and quotes accurately; it cannot establish population-wide demand.

Ask farmers about their last actual sale: crop and grade, kilograms, accepted/rejected quantity, price, all selling deductions, transport arrangement, payment date, alternatives considered and why those alternatives failed. Ask whether credit or an existing agreement affects who they may sell to; do not assume every harvest is freely reallocatable.

Ask buyers for a recent actual order: quantity, acceptable grade, minimum delivery, schedule, packaging, rejection rules, price validity and payment terms. Ask whether they can actually accept split deliveries or cooperative lots.

Ask coordinators who weighs, grades and holds produce; how members approve a pool; who pays for a failed trip; and what happens when one member's produce is rejected. Software cannot resolve those responsibilities by displaying a verification badge.

Use answers to change the fixture and scope. Do not generate fake user quotes or treat an LLM simulation as field validation.

## Business model and adoption hypothesis

Start with a cooperative-assisted pilot. Farmer discovery and plan viewing can be free; a cooperative or aggregator could pay for the multi-farmer planning workspace, offer maintenance and member records. A buyer subscription could later support recurring requirements and supply coordination. These are hypotheses requiring willingness-to-pay evidence, not validated revenue.

Keeping economic recommendations independent of paid placement is important to the proposition. A buyer payment must not secretly improve its ranking. Avoid relying on transaction commission in the first model because sales may complete outside the app and the team will not control fulfillment.

Potential partners are a willing cooperative, municipal agriculture office, DA AMAD contact, one real buyer and a transporter. They are proposed partner types, not established affiliations. Expand one verified crop-and-location network at a time. Useful operational measures include offer freshness, confirmation success, coordinator time per plan, repeat participation and actual after-cost proceeds.

## Pitch and judge questions

**One sentence:** AniWhere helps farmers turn a harvest into a feasible selling plan, showing where each portion can go, what it may return after selling costs, and what to do if a buyer withdraws.

**Short product line:** Know where your harvest can go — and what you could take home.

Suggested demonstration sequence, adaptable to the organizer's actual time limit:

1. Show Ana's harvest and usual outlet.
2. Open the highest-price option and reveal its trip cost and minimum lot.
3. Generate the split plan and optional pool; show each participant's benefit.
4. Withdraw the processor offer in the buyer view.
5. Replan and show the changed proceeds, remaining kilograms and confirmation state.
6. Close on one real user insight, the data boundary and the next pilot step.

**How are you different from TABO or Ani Market?** Those reviewed pages emphasize networks/discovery or pre-harvest matching. AniWhere's prototype centers on allocating an existing harvest under quantity, cost and timing constraints and recalculating when an offer fails. We do not claim those companies lack every comparable feature.

**Where does demand come from?** From timestamped buyer input or a coordinator recording a confirmed conversation. Historical directories provide leads; demonstration offers remain visibly synthetic.

**Is this AI?** The core is explicit optimization and business rules. If an LLM is used, restrict it to parsing a sentence into an editable harvest form or explaining already-computed results. It must not invent prices, buyers or demand.

**Does everyone earn more?** Only under the stated model and the pool's benefit check. Real outcomes depend on acceptance, cost, payment and fulfillment. Show actual measured results only after a pilot.

**What happens when the farmer has no smartphone?** A cooperative operator can enter the harvest and provide the plan through existing communication channels. Automatic SMS or Messenger integrations are future work unless actually built and tested.

**Why would this continue after a hackathon?** The hypothesis is that a cooperative saves coordination time and helps members choose feasible offers. Test repeated use and willingness to pay before expanding.

## Research boundaries and next decision

The sources are a mixture of official agency pages, company self-descriptions, published research/preprints, public repository records and anonymous discussions. No financial transactions, messages, applications, buyer onboarding or deployments were performed. Browser-backed Reddit research was unavailable because the OpenCLI bridge was disconnected; public web-indexed discussion pages were used instead. Agent Reach's Exa search and GitHub CLI returned results.

AniWhere also appears in unrelated web uses, including travel and entertainment. This was a lightweight name search, not domain availability or trademark clearance. Keep the chosen name for the concept while avoiding any claim of exclusive ownership.

**Recommended decision:** proceed with AniPlan as a tightly bounded, explainable split-and-replan prototype. Treat one small pool as supporting functionality. Make the concept note honest about the available evidence, and spend the first day validating a real sale and a real buyer requirement rather than adding features.
